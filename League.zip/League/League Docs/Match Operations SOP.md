NEXGEN MATCH OPERATIONS SOP

Version 1.0 (MVP)

1. Purpose

The Match Operations SOP defines how every official NexGen match is managed from fixture creation to match closure.

Its purpose is to create:

Consistency

Fairness

Accountability

Automation readiness

Scalable league operations

This SOP applies to:

Players

Clubs

Club Managers

Operators

Commissioners

---

2. Match Lifecycle

Every official match follows the same flow.

Fixture Generated
       ↓
Fixture Published
       ↓
Check-In Opens
       ↓
Check-In Closes
       ↓
Match Played
       ↓
Result Submitted
       ↓
Opponent Confirmation
       ↓
Operator Verification
       ↓
Standings Updated
       ↓
Match Closed

No official match should bypass this workflow.

---

3. Match Status System

Every fixture must have a status.

Status 1: Scheduled

Match has been created.

Waiting for check-in.

---

Status 2: Check-In Open

Players may check in.

---

Status 3: Ready

Both sides checked in.

Match can begin.

---

Status 4: In Progress

Match is being played.

---

Status 5: Awaiting Submission

Match completed.

Waiting for result.

---

Status 6: Awaiting Confirmation

Result submitted.

Waiting for opponent response.

---

Status 7: Under Review

Dispute or verification required.

---

Status 8: Verified

Result approved.

---

Status 9: Closed

Fixture finalized.

No further changes allowed.

---

4. Fixture Creation Procedure

Responsible:

Commissioner

League Operator

Required Information:

Match ID
Division
Season
Match Week
Player A
Player B
Date
Time

Once generated:

Fixture becomes official.

---

5. Match Notification Procedure

When fixture is published:

System notifies:

Players

Club Managers

Operators

Notification includes:

Opponent

Date

Time

Match ID

Division

---

6. Check-In Procedure

Opening Time

24 Hours Before Match

---

Closing Time

30 Minutes Before Match

---

Player Actions

Player must:

Open fixture

Press Check-In

Confirm availability

---

Club Manager Actions

Managers should:

Verify player availability

Replace unavailable players (where permitted)

---

Operator Actions

Operators monitor:

Missing check-ins

Risk fixtures

Repeat offenders

---

7. Check-In Failure Procedure

If one player fails to check in:

Status:

Check-In Failure Review

Operator investigates.

Possible outcomes:

Outcome A

Forfeit

Outcome B

Extension

Outcome C

Reschedule

---

8. Match Start Procedure

Match begins at scheduled time.

Players launch:

EA Sports FC

eFootball

Or approved title.

Matches occur outside NexGen.

NexGen only governs competition.

---

9. Match Window

Official Duration:

1 Hour

Matches should start and finish within this period.

---

10. During Match Procedure

Players must:

Follow approved settings

Play assigned opponent

Respect rules

Players must not:

Delay intentionally

Use unauthorized accounts

Manipulate results

---

11. Disconnect Procedure

If disconnect occurs:

Player must:

Capture evidence

Notify opponent

Operator may:

Option 1

Replay match

Option 2

Resume match

Option 3

Escalate

Depends on evidence.

---

12. Match Completion Procedure

When match ends:

Players capture:

Final score

Match summary

Evidence should be retained.

---

13. Result Submission Procedure

Submission Window:

15 Minutes

After match ends.

---

Required Data

Match ID

Player Name

Opponent Name

Score

Screenshot

Timestamp

---

Recommended Submitter

Winning player.

If draw:

Either player.

---

14. Late Submission Procedure

If submission arrives after deadline:

Operator reviews.

Possible outcomes:

Accept

Warning

Forfeit

Depends on circumstances.

---

15. Opponent Confirmation Procedure

Confirmation Window:

12 Hours

Opponent may:

Confirm

Result accepted.

---

Dispute

Result challenged.

---

No Response

Operator review required.

---

16. Result Verification Procedure

Operator verifies:

Match ID

Evidence

Score

Confirmation status

If valid:

Status:

Verified

---

17. Standings Update Procedure

After verification:

System updates:

Wins
Draws
Losses
Goals For
Goals Against
Goal Difference
Points

Standard:

Win = 3
Draw = 1
Loss = 0

---

18. Dispute Procedure

If dispute opened:

Status:

Under Review

Process transfers to:

Dispute Resolution SOP

Operator must not close fixture until dispute ends.

---

19. Match Closure Procedure

Requirements:

✅ Submission Complete

✅ Verification Complete

✅ Disputes Resolved

✅ Standings Updated

---

Status becomes:

Closed

No further modifications allowed.

---

20. Operator Daily Match Checklist

Every active match day:

Review Fixtures

Upcoming matches

Active matches

Delayed matches

---

Review Check-Ins

Missing check-ins

Risk matches

---

Review Submissions

Missing results

Invalid evidence

---

Review Confirmations

Pending confirmations

Disputes

---

Review Standings

Correct updates

No missing fixtures

---

21. Match Escalation Triggers

Immediately escalate:

Competitive Integrity

Account sharing

Match fixing

Collusion

---

Evidence Issues

Fake screenshots

Manipulated evidence

---

Governance Issues

Rule exploitation

Operator conflict

---

22. Emergency Match Procedures

Examples:

Platform Outage

Pause deadlines.

---

Game Server Failure

Extend match window.

---

Mass Connectivity Failure

Commissioner review.

---

Major Tournament Incident

HQ intervention.

---

23. Match Records

Every completed match should store:

Match ID

Season

Division

Week

Players

Club(s)

Score

Evidence

Submission Time

Verification Time

Operator

Dispute Status

Final Status

---

24. Match Success Metrics

Track:

Completion Rate

Target:

95%+

---

On-Time Check-In Rate

Target:

90%+

---

Dispute Rate

Target:

<10%

---

Verification Time

Target:

<24 Hours
League Season Architecture (MVP)

Purpose

Defines how a NexGen season operates from registration to champion selection.

This section becomes the foundation for:

League Operations

Match Management

Standings

Playoffs

Club Participation

Season Automation

---

Season Structure

SA-01: Season Lifecycle

Every league season follows the same structure.

Registration
        ↓
Verification
        ↓
Club Approval
        ↓
Roster Lock
        ↓
Fixture Release
        ↓
Regular Season
        ↓
Playoffs
        ↓
Finals
        ↓
Season Close
        ↓
Rewards Distribution

This creates a predictable competitive cycle.

---

Season Timeline

SA-02: Registration Period

Registration opens before the season begins.

Duration

60 Days

Purpose:

Club formation

Player recruitment

Verification

Sponsor preparation

---

SA-03: Verification & Club Approval

Runs during registration.

League Operations verifies:

Club owners

Rosters

Eligibility

Compliance requirements

---

SA-04: Roster Lock

Occurs before kickoff.

MVP Rule

72 Hours Before Week 1

After roster lock:

No new players

No transfers

No roster modifications

Unless approved by League Operations.

---

League Participation

SA-05: Season Capacity

Season 1 League Capacity:

8 Clubs

Future seasons may increase capacity.

---

SA-06: Club Eligibility

To participate a club must:

Be approved

Meet roster requirements

Have no active sanctions

Accept season regulations

---

Fixture Generation

SA-07: Match Scheduling Model

Season 1 uses a:

Single Round Robin

Meaning:

Every club plays every other club once.

---

Example

8 Clubs

Club A vs Club B
Club A vs Club C
Club A vs Club D
...

Total matches per club:

7

---

Match Weeks

SA-08: Weekly Structure

Season Duration:

8 Weeks

Regular season:

7 Match Weeks

Playoffs:

Week 8

---

SA-09: Weekly Match Requirement

Each club plays:

1 Official League Match Per Week

This minimizes scheduling conflicts.

---

Match Completion

SA-10: Valid Match Conditions

A match is considered valid when:

Both clubs participate

Result is submitted

Evidence requirements are satisfied

No active dispute exists

---

SA-11: Match Result Submission

After completion:

Both clubs must submit:

Result

Score

Supporting evidence

Example:

Screenshot

Match report

Approved game API data (future)

---

Match Confirmation

SA-12: Result Verification

Possible states:

Pending
Confirmed
Disputed
Rejected

---

Automatic Confirmation

If both clubs submit matching results:

Status = Confirmed

---

Conflict

If submissions differ:

Status = Disputed

League Operations reviews.

---

Standings System

SA-13: League Points

Win

3 Points

Draw

1 Point

Loss

0 Points

---

Standings Ranking Order

SA-14: Tie-Breakers

When clubs have equal points:

Order:

1. Total Points

2. Goal Difference

3. Goals Scored

4. Head-to-Head Result

5. League Operations Decision

---

Forfeits

SA-15: Match Forfeit

A club may forfeit when:

It fails to appear

Cannot field minimum roster

Refuses to play

---

Forfeit Result

Recommended:

3-0 Default Win

Awarded to the non-offending club.

---

Point Allocation

Winner:

3 Points

Loser:

0 Points

---

No-Shows

SA-16: No-Show Policy

A no-show occurs when:

Club fails to appear

No valid reason provided

Consequences:

Match forfeiture

Reputation penalties

Operational review

---

Club Withdrawal

SA-17: Season Withdrawal

A club may request withdrawal.

---

Before Week 1

Allowed.

Club removed from fixtures.

---

After Season Start

Not automatically allowed.

League Operations review required.

---

Withdrawal Penalties

SA-18: Mid-Season Withdrawal

Possible consequences:

Loss of rewards eligibility

Reputation penalties

Future participation restrictions

---

Playoff System

SA-19: Qualification

After Week 7:

Top 4 Clubs Qualify

---

SA-20: Semi-Finals

Structure:

1st vs 4th
2nd vs 3rd

---

SA-21: Finals

Semi-final winners advance.

Winner = Season Champion

---

SA-22: Third Place Match

Optional for MVP.

Can be added later.

---

Season Champion

SA-23: Champion Criteria

A club becomes champion by:

Winning the Grand Final

Not by finishing first in the regular season.

Regular season determines playoff seeding only.

---

Season Awards

SA-24: End of Season Awards

Award categories:

League Champion

Runner-Up

Season MVP

Best Club

Fair Play Award

Additional awards may be added later.

---

Season Closure

SA-25: Official Season Close

After finals:

League Operations:

Lock standings

Archive results

Archive fixtures

Update classifications

Process rewards

---

Season States

Every season should have a system state.

Draft
        ↓
Registration Open
        ↓
Verification
        ↓
Roster Locked
        ↓
Active
        ↓
Playoffs
        ↓
Completed
        ↓
Archived

---

Database Entities Required

The architecture now requires:

Season

Season
- ID
- Name
- Start Date
- End Date
- Status

Match Week

MatchWeek
- ID
- Season ID
- Week Number
- Start Date
- End Date

Fixture

Fixture
- Home Club
- Away Club
- Week
- Status

Standings

Club
Points
Wins
Draws
Losses
Goals For
Goals Against
Goal Difference

Playoffs

Semi Final 1
Semi Final 2
Final
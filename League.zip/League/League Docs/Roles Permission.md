Excellent choice.

The Roles & Permissions Matrix should be completed before the Club System Specification because it directly affects:

Authentication

Authorization

Backend APIs

Database design

Admin dashboards

Feature access control

Codex will use this document constantly.

---

NEXGEN ROLES & PERMISSIONS SPECIFICATION

Version 1.0 (MVP)

1. Purpose

This document defines:

Platform roles

Authority hierarchy

System permissions

Administrative boundaries

Access control rules

All platform actions must be authorized through this specification.

---

2. Authority Hierarchy

NexGen HQ
    ↓
Commissioner
    ↓
Operator
    ↓
Club Manager
    ↓
Player

Higher roles inherit lower-level visibility but not necessarily lower-level actions.

---

3. Role Definitions

Player

A registered participant.

Primary purpose:

Compete

Join clubs

Participate in seasons

Build progression

---

Club Manager

Official representative of a club.

Primary purpose:

Manage club operations

Manage roster

Coordinate participation

---

Operator

League administration role.

Primary purpose:

Verify results

Monitor fixtures

Resolve standard disputes

---

Commissioner

League governance role.

Primary purpose:

Manage seasons

Manage divisions

Oversee operators

Handle escalations

---

NexGen HQ

System authority.

Primary purpose:

Platform governance

League governance

Strategic decisions

---

4. Player Permissions

Account

Can:

✅ Register

✅ Login

✅ Edit Profile

✅ Upload Avatar

✅ View Statistics

---

Competition

Can:

✅ Join Seasons

✅ Participate In Fixtures

✅ Submit Results

✅ Confirm Results

✅ Open Disputes

---

Clubs

Can:

✅ Join Club

✅ Leave Club

✅ Accept Recruitment Invitation

✅ Reject Recruitment Invitation

---

Restrictions

Cannot:

❌ Create Seasons

❌ Modify Fixtures

❌ Verify Results

❌ Apply Penalties

❌ Manage Other Players

---

5. Club Manager Permissions

Inherits Player permissions.

Additional permissions:

---

Club Management

Can:

✅ Create Club Application

✅ Edit Club Profile

✅ Manage Club Information

---

Roster Management

Can:

✅ Invite Players

✅ Remove Players

✅ Approve Roster Changes

✅ View Club Roster

---

Match Operations

Can:

✅ View Club Fixtures

✅ Coordinate Team Participation

✅ Submit Club Evidence

---

Restrictions

Cannot:

❌ Create Divisions

❌ Create Seasons

❌ Verify Results

❌ Apply Penalties

❌ Modify League Standings

---

6. Operator Permissions

Operator is the first operational role.

---

Match Management

Can:

✅ Review Fixtures

✅ Monitor Check-Ins

✅ Review Results

✅ Verify Results

---

Dispute Management

Can:

✅ Review Disputes

✅ Request Evidence

✅ Issue Standard Rulings

---

Penalties

Can:

✅ Issue Warnings

✅ Issue Match Forfeits

---

Restrictions

Cannot:

❌ Permanently Ban Users

❌ Modify Constitution

❌ Create New Divisions

❌ Override Commissioner Decisions

---

7. Commissioner Permissions

Inherits Operator permissions.

---

Season Management

Can:

✅ Create Seasons

✅ Configure Season Dates

✅ Open Registration

✅ Close Registration

---

Division Management

Can:

✅ Create Divisions

✅ Assign Participants

✅ Approve Placements

---

Governance

Can:

✅ Escalate Investigations

✅ Apply Major Penalties

✅ Suspend Participants

---

Staff Management

Can:

✅ Assign Operators

✅ Remove Operators

---

Restrictions

Cannot:

❌ Modify Constitution

❌ Modify Platform Ownership

❌ Override NexGen HQ

---

8. NexGen HQ Permissions

Full Authority.

---

Governance

Can:

✅ Modify Constitution

✅ Modify Rulebook

✅ Create Policies

✅ Approve Governance Changes

---

League Control

Can:

✅ Create Leagues

✅ Remove Leagues

✅ Restructure Divisions

✅ Approve Promotions

✅ Approve Relegations

---

Enforcement

Can:

✅ Permanently Ban Participants

✅ Remove Clubs

✅ Remove Officials

✅ Resolve Final Appeals

---

Platform Administration

Can:

✅ Manage All Users

✅ Manage All Seasons

✅ Manage All Divisions

✅ Manage All Records

---

9. System Role Matrix

Action	Player	Club Manager	Operator	Commissioner	HQ

Register	✅	✅	✅	✅	✅
Join Season	✅	✅	✅	✅	✅
Submit Result	✅	✅	✅	✅	✅
Confirm Result	✅	✅	✅	✅	✅
Open Dispute	✅	✅	✅	✅	✅
Manage Club	❌	✅	❌	❌	✅
Invite Players	❌	✅	❌	❌	✅
Verify Result	❌	❌	✅	✅	✅
Resolve Dispute	❌	❌	✅	✅	✅
Create Season	❌	❌	❌	✅	✅
Create Division	❌	❌	❌	✅	✅
Suspend User	❌	❌	❌	✅	✅
Permanent Ban	❌	❌	❌	❌	✅
Modify Constitution	❌	❌	❌	❌	✅

---

10. MVP Database Roles

Codex should implement:

PLAYER

CLUB_MANAGER

OPERATOR

COMMISSIONER

HQ_ADMIN

Single source of truth.

Stored on user account.

---

11. Future Roles (Not MVP)

Do not build yet.

Potential future roles:

Sponsor

Scout

League Moderator

Regional Director

Analyst

Caster

Referee

These should remain outside MVP scope.
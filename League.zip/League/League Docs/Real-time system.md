The key rule: the database is the source of truth. Realtime is only a delivery and UX layer. No websocket state should ever be trusted as authoritative.

1) Event model principles

Event categories

1. Lifecycle events
Season, club, player, match, dispute, penalty, application state changes.

2. Workflow events
Check-in open/close, result submission, opponent confirmation, operator review, escalation.

3. Notification events
In-app alerts and optional email/SMS/WhatsApp notifications.

4. Audit events
Immutable trace of who changed what, when, and why.

5. Read-model sync events
Used to update standings, dashboards, and live lists.

Core design rules

One command write, one DB transaction, one durable event record.

Event emission happens after DB commit using a simple outbox pattern.

Every event is idempotent.

Every aggregate has a monotonic version number.

Client UI can reconnect and resync from last known version.

Realtime delivery may fail; the league state must not.

---

2) Standard event envelope

Every event should carry this envelope:

event_id
event_name
event_category
occurred_at
aggregate_type
aggregate_id
aggregate_version
season_id
club_id(s)
match_id
dispute_id
penalty_id
application_id
actor_type
actor_id
actor_role
request_id
correlation_id
causation_id
source
reason
metadata

Standard metadata fields

reason — human-readable reason for the action

metadata — event-specific payload

source — admin panel, player app, operator dashboard, system job, webhook, etc.

---

3) Domain event specification

A. Season events

Event name	When it fires	Payload fields	Receivers	System action	Realtime	Durable	Retry/failure

season.created	Admin creates a season draft	season_id, name, format, division_count, start_date, end_date, created_by	Admin/HQ, commissioners, audit, scheduler	Creates season record in Draft	No	Yes	Retry outbox publish; no retry on DB failure
season.registration_opened	Registration is opened	season_id, opens_at, closes_at	Players, clubs, admin, notifications	Makes season joinable	Yes	Yes	Retry notify; poll fallback
season.registration_closed	Registration closes	season_id, closed_at	Admin, operators, players, clubs	Locks new applications	Yes	Yes	Retry notify
season.activated	Season enters live competition	season_id, active_from, fixture_batch_id?	All active participants, standings engine, operators	Allows fixtures and standings updates	Yes	Yes	Retry publish; poll fallback
season.playoffs_started	Playoffs begin	season_id, bracket_id	Players, clubs, operators	Locks regular-season logic, enables playoffs mode	Yes	Yes	Retry publish
season.completed	Season ends	season_id, completed_at, final_rankings_ref	Everyone relevant	Freezes competitive state	Yes	Yes	Retry publish
season.archived	Season is archived	season_id, archived_at	Admin, audit	Locks historical record	No	Yes	Retry outbox

Season guards

No season.activated unless registration is closed.

No season.completed unless the active/playoff phase is finished.

No fixture creation outside a valid season lifecycle state.

---

B. Club application events

Event name	When it fires	Payload fields	Receivers	System action	Realtime	Durable	Retry/failure

club.application_submitted	Club founder submits application	application_id, club_name, owner_id, division_preference, documents_ref, submitted_at	Admin, operators, applicant, audit	Creates application in Submitted	Yes	Yes	Retry notify
club.application_review_started	Operator opens application for review	application_id, reviewer_id, started_at	Admin, audit, applicant	Locks review ownership	Yes	Yes	Retry publish
club.application_approved	Application is approved	application_id, club_id, approved_by, approved_at	Applicant, club manager, admin, standings/club service	Creates club record	Yes	Yes	Retry publish
club.application_rejected	Application is rejected	application_id, rejected_by, reason_code, rejected_at	Applicant, audit	Closes application	Yes	Yes	Retry publish
club.application_withdrawn	Applicant withdraws	application_id, withdrawn_by, withdrawn_at	Admin, audit	Closes application	Yes	Yes	Retry publish

Club application guards

Only one active application per club identity/profile unless explicitly allowed by admin.

Approved application must create the club atomically or not at all.

---

C. Club lifecycle events

Event name	When it fires	Payload fields	Receivers	System action	Realtime	Durable	Retry/failure

club.created	Club is created after approval	club_id, owner_id, name, division_id, created_at	Club manager, players, admin, audit	Opens club profile	Yes	Yes	Retry publish
club.roster_member_added	Player joins club roster	club_id, player_id, role, joined_at, season_id	Club manager, player, admin	Updates roster	Yes	Yes	Retry publish
club.roster_member_removed	Player leaves club	club_id, player_id, removed_at, reason	Club manager, player, admin	Removes roster link	Yes	Yes	Retry publish
club.suspended	Club is suspended	club_id, suspended_by, reason_code, suspended_until?	Club manager, players, admin, operators	Blocks participation	Yes	Yes	Retry publish
club.reactivated	Suspension lifted	club_id, reactivated_by, reactivated_at	Club, admin	Restores participation	Yes	Yes	Retry publish
club.removed	Club is removed from competition	club_id, removed_by, reason_code, removed_at	Club, admin, audit	Inactivates club	Yes	Yes	Retry publish
club.archived	Club is archived	club_id, archived_at	Admin, audit	Locks record	No	Yes	Retry outbox

Club lifecycle guards

A club cannot be active without an owner/manager and valid roster baseline.

Suspended clubs cannot submit match actions.

Removed clubs cannot re-enter the same season without admin override.

---

D. Player lifecycle events

Event name	When it fires	Payload fields	Receivers	System action	Realtime	Durable	Retry/failure

player.registered	User completes player signup	player_id, gamertag, account_id, registered_at	Player, admin, audit	Creates player profile	Yes	Yes	Retry publish
player.verified	Operator/admin verifies player	player_id, verified_by, verified_at, verification_level	Player, club manager, admin	Marks player eligible	Yes	Yes	Retry publish
player.club_joined	Player joins a club	player_id, club_id, joined_at, season_id	Player, club manager, admin	Assigns membership	Yes	Yes	Retry publish
player.club_left	Player leaves club	player_id, club_id, left_at, reason	Player, club manager, admin	Removes membership	Yes	Yes	Retry publish
player.suspended	Player is suspended	player_id, suspended_by, reason_code, suspended_until?	Player, club manager, admin	Blocks competition access	Yes	Yes	Retry publish
player.banned	Player is banned	player_id, banned_by, reason_code, banned_at	Player, club manager, admin	Locks account participation	Yes	Yes	Retry publish
player.retired	Player exits competitive system	player_id, retired_at	Player, admin	Marks inactive	Yes	Yes	Retry publish

Player lifecycle guards

A player can only belong to one active club at a time.

Suspended/banned players cannot check in, submit, or confirm results.

---

E. Match lifecycle events

This is the most important workflow.

Event name	When it fires	Payload fields	Receivers	System action	Realtime	Durable	Retry/failure

match.created	Fixture is generated	match_id, season_id, division_id, home_club_id, away_club_id, scheduled_for, match_window_starts_at, match_window_ends_at, checkin_opens_at, checkin_closes_at	Players, clubs, operators, admin	Creates fixture	Yes	Yes	Retry publish
match.published	Fixture is visible to participants	match_id, published_at	Players, clubs, operators	Makes match public in dashboard	Yes	Yes	Retry publish
match.checkin_opened	Check-in window opens	match_id, checkin_opens_at	Players, clubs, operators	Enables check-in	Yes	Yes	Retry publish
match.checkin_reminder_sent	Reminder dispatched before deadline	match_id, recipient_id, reminder_type	Target users	Sends reminder notification	Yes	Yes	Retry notify
match.checkin_closed	Check-in window expires	match_id, checkin_closes_at	Players, clubs, operators	Locks check-in state	Yes	Yes	Retry publish
match.started	Match has officially started	match_id, started_at, started_by	Participants, operators	Marks in-progress state	Yes	Yes	Retry publish
match.result_submitted	A result is submitted	match_id, submitted_by, submitted_at, score_home, score_away, evidence_ref[], submission_id	Opponent, operators, admin, notification service	Moves to review queue	Yes	Yes	Retry publish
match.result_confirmed_by_opponent	Opponent confirms submitted result	match_id, confirmed_by, confirmed_at	Operator, admin, participants	Moves toward approval	Yes	Yes	Retry publish
match.result_rejected_by_opponent	Opponent disputes result submission	match_id, rejected_by, rejected_at, reason_code	Operator, admin, participants	Opens dispute flow	Yes	Yes	Retry publish
match.result_approved	Operator/admin approves result	match_id, approved_by, approved_at, winner_club_id, points_awarded, stats_delta_ref	Everyone affected, standings engine, audit	Finalizes result, updates standings	Yes	Yes	Retry publish
match.forfeited	Admin/operator applies forfeit	match_id, forfeited_by, forfeited_at, forfeiting_side, reason_code, points_awarded	Participants, standings engine, audit	Applies win/loss and points	Yes	Yes	Retry publish
match.voided	Match is cancelled/invalidated	match_id, voided_by, reason_code, voided_at	Participants, admin, audit	Removes from scoring	Yes	Yes	Retry publish
match.disputed	Formal dispute is opened on a match	match_id, dispute_id, opened_by, opened_at, dispute_type	Operators, admin, participants	Pauses finalization path	Yes	Yes	Retry publish
match.closed	Match lifecycle is completed	match_id, closed_at, close_reason	Participants, admin, audit	Locks match record	Yes	Yes	Retry publish
match.archived	Match is archived at season close	match_id, archived_at	Admin, audit	Locks history	No	Yes	Retry outbox

Match lifecycle guards

match.result_submitted must reference a valid match and occur before closure cutoff.

match.result_approved cannot happen if the match is disputed or voided.

match.forfeited requires a valid operator/admin ruling.

match.closed must happen after a final result, forfeit, or void.

Match transitions that affect standings/points

match.result_approved

match.forfeited

match.voided does not affect standings directly except by reversing a previously provisional state

Any later correction event that changes winner/loss/score must trigger a standings recompute

---

F. Result submission and confirmation events

These are split out because they are workflow-critical and noisy.

Event name	When it fires	Payload fields	Receivers	System action	Realtime	Durable	Retry/failure

result.submission_created	Player or club submits score/evidence	submission_id, match_id, submitted_by, score_home, score_away, evidence_ref[], submitted_at	Opponent, operators, admin	Creates submission record	Yes	Yes	Retry publish
result.submission_acknowledged	System accepts submission and queues it	submission_id, acknowledged_at	Submitter	Confirms receipt	Yes	Yes	Retry publish
result.opponent_confirmation_pending	Submission awaits opponent action	submission_id, expires_at	Opponent	Opens confirmation window	Yes	Yes	Retry publish
result.confirmed	Opponent confirms	submission_id, confirmed_by, confirmed_at	Operators, admin, standings engine	Moves result toward approval	Yes	Yes	Retry publish
result.rejected	Opponent rejects	submission_id, rejected_by, reason_code, rejected_at	Operators, admin	Opens dispute/review path	Yes	Yes	Retry publish
result.approved	Operator final approval	submission_id, approved_by, approved_at	All affected	Finalizes result	Yes	Yes	Retry publish
result.escalated	Operator escalates to commissioner/HQ	submission_id, escalated_by, escalation_reason	Commissioner, HQ, audit	Escalation routing	Yes	Yes	Retry publish

Result workflow guards

Submission must be tied to one match only.

Duplicate submissions for the same match/version must be rejected idempotently.

Confirmation must match the current open submission.

Approval must not bypass a pending dispute.

---

G. Dispute lifecycle events

Event name	When it fires	Payload fields	Receivers	System action	Realtime	Durable	Retry/failure

dispute.opened	A dispute is formally filed	dispute_id, match_id, opened_by, dispute_type, reason_code, evidence_ref[], opened_at	Operators, commissioner, participants, audit	Creates dispute case	Yes	Yes	Retry publish
dispute.triaged	Operator begins review	dispute_id, triaged_by, triaged_at, priority	Admin, audit	Assigns case handling	Yes	Yes	Retry publish
dispute.under_review	Case is actively being reviewed	dispute_id, reviewer_id, started_at	Admin, audit	Locks review state	Yes	Yes	Retry publish
dispute.escalated	Operator escalates to commissioner/HQ	dispute_id, escalated_by, reason_code, escalated_at	Commissioner, HQ	Routes upward	Yes	Yes	Retry publish
dispute.resolved	Final ruling issued	dispute_id, resolved_by, resolution_type, resolved_at, affected_match_id, outcome_ref	Participants, standings engine, audit	Applies ruling	Yes	Yes	Retry publish
dispute.rejected	Dispute dismissed	dispute_id, rejected_by, reason_code, rejected_at	Participants, audit	Closes case without changes	Yes	Yes	Retry publish
dispute.closed	Dispute fully closed	dispute_id, closed_at	Admin, audit	Locks dispute	Yes	Yes	Retry publish

Dispute guards

A dispute must reference a valid match/result context.

A dispute cannot be opened on an already archived match unless the HQ override path exists.

Resolution can alter match result, forfeit, penalty, or both.

Dispute transitions that affect standings/points

dispute.resolved if it changes match outcome, score, or penalties

dispute.rejected does not affect standings

---

H. Penalty / sanction events

Event name	When it fires	Payload fields	Receivers	System action	Realtime	Durable	Retry/failure

penalty.proposed	Operator proposes sanction	penalty_id, target_type, target_id, penalty_type, reason_code, proposed_by, proposed_at, severity	Commissioner/HQ, audit	Opens penalty case	Yes	Yes	Retry publish
penalty.review_started	Authorized reviewer starts review	penalty_id, reviewer_id, started_at	Admin, audit	Locks review ownership	Yes	Yes	Retry publish
penalty.approved	Penalty is approved	penalty_id, approved_by, approved_at, penalty_type, duration?, points_delta?, match_id?	Target, standings engine, audit	Makes penalty actionable	Yes	Yes	Retry publish
penalty.activated	Penalty takes effect	penalty_id, activated_at, effective_from, effective_until?	Target, admin, standing engine	Enforces suspension/deduction/ban	Yes	Yes	Retry publish
penalty.revoked	Penalty is reversed by authority	penalty_id, revoked_by, revoked_at, reason_code	Target, admin, standings engine, audit	Restores eligibility or points	Yes	Yes	Retry publish
penalty.expired	Time-bound penalty ends	penalty_id, expired_at	Target, admin	Clears active sanction	Yes	Yes	Retry publish

Penalty guards

A penalty cannot become active without approval unless the constitution/rulebook says immediate interim action is allowed.

Point deductions must trigger standings recomputation immediately.

Suspensions and bans must update eligibility immediately.

Penalty transitions that affect standings/points

penalty.approved when points_delta exists

penalty.activated when it includes an active match forfeit or point deduction

penalty.revoked if it reverses a deduction

---

I. Notification events

Notifications are not the source of truth. They are delivery records attached to domain events.

Event name	When it fires	Payload fields	Receivers	System action	Realtime	Durable	Retry/failure

notification.queued	A domain event requires a user-facing message	notification_id, channel, recipient_id, template_key, reference_event_id, dedupe_key	Notification service	Queues message	No	Yes	Retry queue worker
notification.sent	Message handed off to channel	notification_id, channel, sent_at, provider_message_id?	Notification audit	Marks as sent	No	Yes	Retry provider call
notification.delivered	Channel confirms delivery	notification_id, delivered_at	Notification audit	Updates delivery status	No	Yes	Retry on provider ack failure
notification.read	User reads in-app notification	notification_id, read_at	Audit, inbox	Marks acknowledged	No	Yes	No retry needed
notification.failed	Delivery fails permanently	notification_id, failure_reason, failed_at	Admin optionally	Marks failed, leaves league event intact	No	Yes	Retry limited then dead-letter

Notification invariants

Notifications are deduped by dedupe_key.

A failed notification must never roll back the domain action.

In-app notification is mandatory; email/SMS/WhatsApp are optional adapters.

---

4) Who produces events

Event producers

Player app: registration, check-in, result submission, dispute filing, club actions where permitted

Club manager dashboard: roster actions, result confirmation, club application actions

Operator dashboard: verification, result approval, dispute review, penalty review

Commissioner/HQ admin panel: season actions, escalations, sanctions, overrides

System jobs: deadlines, reminders, automatic check-in close, expiry, archival

Notification worker: delivery status events only

Event consumers

Realtime gateway: pushes live updates to clients

Standings engine: recomputes tables and rankings

Notification service: creates user alerts

Audit log service: writes immutable history

Operator dashboard: pending tasks, escalations, live cases

Player/club apps: match status, result status, disputes, standings

Admin/HQ dashboard: all critical actions and escalations

---

5) Event ordering rules

These rules keep the system sane.

1. Per aggregate ordering is strict

Match events must be processed in match version order.

Same for season, club, player, dispute, penalty, application.

2. Global ordering is not required

A penalty event can arrive after the related match event in transport, but the database state must still resolve correctly.

3. Command-before-event

Validate command against current DB state before emitting anything.

4. No approval before submission

result.approved cannot exist before result.submission_created.

5. No dispute resolution before dispute opened

Obvious, but this is where sloppy systems break.

6. Standings update only after finality

Update standings only after approved result, forfeit, or resolved dispute that changes outcome.

7. Terminal states stop normal transitions

Archived/closed items do not continue mutating except via HQ override or explicit reopen path.

---

6) Retry rules

Realtime push retries

Retry 3 times with short exponential backoff.

If push fails, the event stays durable and the client can recover by polling.

Notification retries

Retry provider delivery several times.

After repeated failure, mark notification.failed and stop.

Do not block the league workflow.

Outbox retries

Outbox worker retries until success or dead-letter threshold.

Outbox failure must never prevent the DB write from standing.

Idempotency

Every mutation endpoint must accept an idempotency key so duplicate taps or network retries do not create duplicate events.

---

7) Failure handling

If realtime fails

Keep the DB write.

Keep the durable event.

Queue notification.

Client refresh/poll retrieves the latest state.

If notification delivery fails

Mark delivery failed.

Leave domain state untouched.

Show in-app notification on next successful sync.

If operator action is partial

Either the transaction commits fully or it fails fully.

No half-approved results.

If a duplicate event arrives

Ignore it using event_id and aggregate version.

If a client misses updates

On reconnect, client sends last_seen_event_version or last_seen_state_version.

Server returns snapshot plus delta.

If delta is too old, force full refresh.

---

8) What must be realtime vs what can wait

Must be pushed instantly

Match published

Check-in open/close

Result submitted

Result confirmed/rejected

Dispute opened/escalated/resolved

Penalty approved/activated/revoked

Standings changed

Season opened/closed/started/completed

Club application approved/rejected

Player suspension/ban

Can wait a little

Reminder notifications

Delivery receipts

Audit-only events exposed only in admin logs

Non-critical profile updates

Archived state changes

Background reconciliation updates

---

9) Notification trigger rules

Trigger notifications for

Fixture assigned

Check-in opening

Check-in closing warning

Result submission received

Opponent confirmation request

Dispute filed

Operator ruling issued

Penalty issued

Season registration open/close

Club application decision

Suspension or ban applied

Do not trigger notifications for

Pure audit noise

Internal technical retries

Silent read-model syncs

Non-user-visible reconciliation unless it changes something users must act on

---

10) In-app notifications

Mandatory for MVP.

In-app inbox items should include

Title

Message

Severity

Reference type and ID

Action button

Read/unread status

Created at

Expiry if applicable

Examples

“Check-in opens in 2 hours”

“Opponent submitted result”

“Your dispute was escalated”

“Your club application was approved”

“Penalty applied to your account”

---

11) Email / SMS / WhatsApp readiness

For MVP, build the system channel-agnostic but do not depend on external channels.

Recommended policy

In-app notifications: mandatory

Email: optional adapter

SMS: optional adapter

WhatsApp: optional adapter only if you have a clean business API setup

Reality check

WhatsApp and SMS are useful for urgent match actions, but they add cost, provider failure, and policy overhead.

Use them as adapters, not as core workflow dependencies.

---

12) Realtime update coverage

Must support live updates for

Standings

Match state

Check-ins

Result submissions

Disputes

Operator rulings

Penalty changes

Season phase changes

Read model strategy

Each live screen should subscribe to a narrow topic:

season:{seasonId}

match:{matchId}

club:{clubId}

player:{playerId}

dispute:{disputeId}

admin:live

operator:live

---

13) Polling fallback rules

Realtime is support infrastructure, not the truth.

Fallback behavior

Client reconnects after websocket disconnect.

Client polls current snapshot if last event gap is unknown.

Client polls every 15–30 seconds for active match pages, dispute pages, and operator queues.

Less active screens can poll slower.

What polling should return

Current state snapshot

Latest version number

Pending actions

Any missed events since version X

When to force full refresh

Version gap too large

Session expired

Snapshot integrity mismatch

Critical state changed while offline

---

14) Admin/operator live updates

Operators must see instantly

New fixtures

Check-in failures

Late submissions

Pending confirmations

New disputes

Escalations

Forfeit candidates

Penalty approvals pending

Matches needing review

Commissioner/HQ must see instantly

Escalated disputes

Match anomalies

Repeated no-shows

Suspicion of cheating

Suspensions and bans

Season phase changes

High-impact standings changes

---

15) Audit event linkage

Every domain event must link to an audit record.

Audit record should include

audit_id

event_id

aggregate_type

aggregate_id

before_state

after_state

actor_id

actor_role

action_source

reason

evidence_ref

request_id

correlation_id

created_at

Must be audited

All match state changes

All dispute actions

All penalty actions

All season changes

All club approvals/rejections

All player suspensions/bans

All standings-affecting events

---

16) Duplicate notification prevention

Use all of these together:

1. Event idempotency key

2. Notification dedupe key

3. Per-recipient inbox uniqueness

4. Outbox unique constraint

5. Aggregate version check

Suggested dedupe key:

{event_name}:{aggregate_id}:{recipient_id}:{aggregate_version}

This kills duplicate spam cleanly.

---

17) Missed realtime update handling

If a client missed updates

Compare last_seen_version against current aggregate version.

Fetch missing events or just fetch current snapshot if too many were missed.

Re-render from DB state, not from stale websocket memory.

If an operator missed a critical update

Operator queue must show a “missed update” badge based on version gap.

Critical changes should also surface via persistent inbox notifications.

---

18) Simple MVP implementation recommendation

Do this, and do not overcomplicate it:

Database transaction

Outbox table

Background dispatcher

Realtime gateway

Notification worker

Standings recompute worker

Audit writer

That is enough.

Do not build a heavyweight distributed event bus for MVP. It is unnecessary risk.

---

19) Final rule summary

Instant + durable

Match lifecycle changes

Result submission and approval

Disputes

Penalties

Season phase changes

Club application decisions

Durable only

Audit events

Notification delivery events

Background sync events

Not source of truth

Websocket state

Push delivery

UI badges

Notification read receipts
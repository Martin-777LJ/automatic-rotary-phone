1. MATCH LIFECYCLE

Purpose

Controls a fixture from creation through closure.

---

States

State	Description

Draft	Fixture created but not published
Scheduled	Fixture published and visible
Check-In Open	Check-in window active
Check-In Closed	Check-in window closed
In Progress	Match currently being played
Submission Pending	Awaiting result submission
Under Review	Result submitted and awaiting confirmation
Disputed	Formal dispute opened
Confirmed	Result approved
Forfeited	Match awarded due to no-show/violation
Void	Match cancelled
Archived	Historical record

---

Master Diagram

Draft
 ↓
Scheduled
 ↓
Check-In Open
 ↓
Check-In Closed
 ↓
In Progress
 ↓
Submission Pending
 ↓
Under Review
 ├─→ Disputed
 │      ↓
 │   Confirmed
 │
 └─→ Confirmed

Confirmed
 ↓
Archived

Check-In Closed
 ↓
Forfeited
 ↓
Archived

Any Pre-Confirmed State
 ↓
Void
 ↓
Archived

---

Transition Table

From	To	Trigger

Draft	Scheduled	Fixture published
Scheduled	Check-In Open	Check-in window opens
Check-In Open	Check-In Closed	Deadline reached
Check-In Closed	In Progress	Match started
In Progress	Submission Pending	Match completed
Submission Pending	Under Review	Result submitted
Under Review	Confirmed	Result approved
Under Review	Disputed	Dispute filed
Disputed	Confirmed	Ruling issued
Check-In Closed	Forfeited	No-show ruling
Any Active State	Void	Admin cancellation
Confirmed	Archived	Season archival
Forfeited	Archived	Season archival
Void	Archived	Season archival

---

Triggers

Player

Check in

Submit result

Open dispute

Club Manager

Confirm result

Submit evidence

Operator

Approve result

Apply forfeit

Escalate dispute

Commissioner/HQ

Void fixture

Final ruling

---

Guards

In Progress

Requires:

Fixture published

Match window active

Under Review

Requires:

Result submitted

Evidence attached

Confirmed

Requires:

Valid evidence

No unresolved dispute

Forfeited

Requires:

No-show evidence

Operator review

---

Invalid Transitions

Forbidden:

Draft → Confirmed
Scheduled → Confirmed
In Progress → Archived
Disputed → Archived
Forfeited → Confirmed
Archived → Active

---

Terminal States

Archived

---

Rollback Rules

Only Commissioner/HQ may reopen:

Confirmed → Disputed
Confirmed → Under Review
Forfeited → Disputed

Audit log mandatory.

---

System Actions

Confirmed

System:

Update standings

Update player stats

Update club stats

Award points

Forfeited

System:

Apply loss

Apply win

Trigger penalty review if required

Archived

System:

Lock fixture

---

Audit Logging

Log:

Creation

Publication

Check-in status

Submission

Approval

Dispute creation

Rulings

Forfeits

Voids

---

Standings Impact

Affected:

Confirmed

Forfeited

Not affected:

Disputed

Void

---

2. SEASON LIFECYCLE

States

State

Draft
Registration Open
Registration Closed
Active
Playoffs
Completed
Archived

---

Diagram

Draft
 ↓
Registration Open
 ↓
Registration Closed
 ↓
Active
 ↓
Playoffs
 ↓
Completed
 ↓
Archived

---

Transitions

From	To

Draft	Registration Open
Registration Open	Registration Closed
Registration Closed	Active
Active	Playoffs
Playoffs	Completed
Completed	Archived

---

Trigger Authority

Action	Role

Create season	Admin
Open registration	Admin
Start season	Admin
Start playoffs	Admin
Close season	Admin/HQ

---

Data Changes

Active

Generate:

Divisions

Fixtures

Standings

Completed

Freeze:

Rankings

Promotions

Relegations

Archived

Lock records

---

Standings Impact

Active state enables standings updates.

---

3. CLUB LIFECYCLE

States

State

Draft
Pending Approval
Active
Suspended
Removed
Archived

---

Diagram

Draft
 ↓
Pending Approval
 ↓
Active
 ├─→ Suspended
 │      ↓
 │    Active
 │
 └─→ Removed
        ↓
     Archived

---

Triggers

Founder

Submit club

Admin

Approve club

Commissioner

Suspend club

HQ

Remove club

---

Guards

Active requires:

Club manager assigned

Minimum roster requirements

---

Terminal States

Archived

---

Data Changes

Active

Eligible for:

Recruitment

Competition

Suspended

Cannot:

Recruit

Participate

---

Standings Impact

Suspended clubs may have fixtures frozen.

Removed clubs trigger administrative review.

---

4. PLAYER LIFECYCLE

States

State

Registered
Verified
Free Agent
Club Member
Suspended
Banned
Retired
Archived

---

Diagram

Registered
 ↓
Verified
 ↓
Free Agent
 ↓
Club Member

Club Member
 ↓
Free Agent

Verified
 ↓
Suspended
 ↓
Verified

Any Active
 ↓
Banned
 ↓
Archived

---

Inferred States

Verified

Not explicitly defined.

Required because operators can verify players.

---

Terminal States

Archived

---

Data Changes

Club Member

Roster record created

Suspended

Player ineligible

Banned

Account locked

---

Standings Impact

Suspensions may trigger forfeits.

---

5. DISPUTE LIFECYCLE

States

State

Draft
Submitted
Under Review
Escalated
Resolved
Rejected
Closed

---

Diagram

Draft
 ↓
Submitted
 ↓
Under Review
 ├─→ Escalated
 │      ↓
 │   Resolved
 │
 ├─→ Resolved
 │
 └─→ Rejected

Resolved
 ↓
Closed

Rejected
 ↓
Closed

---

Triggers

Player

Submit dispute

Operator

Review

Commissioner

Escalate review

HQ

Final decision

---

Guards

Must reference:

Fixture

Evidence

---

Data Changes

Resolved

Apply:

Result changes

Penalties

---

Standings Impact

Possible if dispute overturns result.

---

6. PENALTY / SANCTION LIFECYCLE

States

State

Proposed
Under Review
Approved
Active
Expired
Revoked

---

Diagram

Proposed
 ↓
Under Review
 ↓
Approved
 ↓
Active
 ├─→ Expired
 └─→ Revoked

---

Types

Warning

Point Deduction

Match Forfeit

Suspension

Ban

---

Authority

Penalty	Authority

Warning	Operator
Point Deduction	Operator + Commissioner
Suspension	Commissioner
Ban	HQ

---

Standings Impact

Point Deduction

Immediately recalculates standings.

Match Forfeit

Recalculates standings.

---

7. CLUB APPLICATION LIFECYCLE

States

State

Draft
Submitted
Under Review
Approved
Rejected
Withdrawn

---

Diagram

Draft
 ↓
Submitted
 ↓
Under Review
 ├─→ Approved
 ├─→ Rejected
 └─→ Withdrawn

---

Data Changes

Approved

Create Club record.

Rejected

Application locked.

---

Terminal States

Approved

Rejected

Withdrawn

---

8. RESULT SUBMISSION & CONFIRMATION LIFECYCLE

States

State

Awaiting Submission
Submitted
Awaiting Opponent Confirmation
Operator Review
Confirmed
Rejected
Disputed

---

Diagram

Awaiting Submission
 ↓
Submitted
 ↓
Awaiting Opponent Confirmation
 ├─→ Confirmed
 ├─→ Operator Review
 └─→ Disputed

Operator Review
 ├─→ Confirmed
 ├─→ Rejected
 └─→ Disputed

---

Triggers

Player

Submit result

Opponent

Confirm result

Operator

Approve result

---

Guards

Requires:

Score

Evidence

Fixture linkage

---

Standings Impact

Only:

Confirmed

affects standings.

---

9. NOTIFICATION LIFECYCLE

Notifications are workflow-supporting states.

---

States

State

Queued
Sent
Delivered
Acknowledged
Expired
Failed

---

Diagram

Queued
 ↓
Sent
 ↓
Delivered
 ↓
Acknowledged

Sent
 ↓
Failed

Delivered
 ↓
Expired

---

Workflow-Critical Notifications

Season

Registration opened

Registration closing

Season started

Match

Fixture assigned

Check-in opened

Check-in closing

Result pending

Disputes

Dispute received

Ruling issued

Penalties

Penalty issued

Suspension active

---

AUDIT LOG REQUIREMENTS

Every state change below MUST generate immutable audit entries:

Match

All transitions

Season

All transitions

Club

Approval

Suspension

Removal

Player

Verification

Suspension

Ban

Disputes

Submission

Escalation

Resolution

Penalties

Proposal

Approval

Activation

Revocation

Results

Submission

Confirmation

Rejection

---

STANDINGS ENGINE TRIGGERS

Only the following transitions recalculate standings:

Match:
Under Review → Confirmed
Disputed → Confirmed
Check-In Closed → Forfeited

Penalty:
Approved → Active (Point Deduction)
Approved → Active (Match Forfeit)

Dispute:
Resolved (when ruling changes result)

Everything else is non-scoring and must not modify standings.
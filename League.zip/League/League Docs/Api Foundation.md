1. API FOUNDATION

Base URL

https://api.nexgenesport.com/api/v1

---

Authentication Strategy

Authentication

JWT Access Token

Authorization: Bearer <access_token>

Token Types

Token| Lifetime
Access Token| 15 minutes
Refresh Token| 30 days

Identity Types

- Player
- Club Manager
- Moderator
- Match Operator
- League Commissioner
- NexGen HQ Admin

---

Role Hierarchy

HQ Admin
 └─ League Commissioner
      └─ Match Operator
           └─ Moderator

Club Manager
Player

Higher roles inherit lower administrative permissions.

---

RBAC Enforcement

Every protected endpoint requires:

{
  "userId": "uuid",
  "role": "PLAYER"
}

Middleware validates:

- JWT validity
- Account status
- Suspension status
- Role authorization

---

Resource Naming

Use plural nouns.

Examples:

/users
/players
/clubs
/seasons
/matches
/disputes

---

Pagination Standard

Request:

GET /players?page=1&limit=20

Response:

{
  "data": [],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 240,
    "pages": 12
  }
}

---

Sorting

?sort=createdAt
?order=asc
?order=desc

---

Error Format

{
  "success": false,
  "error": {
    "code": "MATCH_NOT_FOUND",
    "message": "Match does not exist"
  }
}

---

Common Status Codes

Code| Meaning
200| Success
201| Created
204| No Content
400| Validation Error
401| Unauthorized
403| Forbidden
404| Not Found
409| Conflict
422| Business Rule Violation
500| Server Error

---

Versioning Strategy

/api/v1

Breaking changes create:

/api/v2

---

Request Validation Standards

UUIDs required for all IDs.

Strings trimmed.

Maximum lengths enforced.

Dates ISO-8601.

Enum validation mandatory.

Unknown fields rejected.

---

2. AUTHENTICATION

Register

POST /auth/register

Roles:

- Public

Request

{
  "email": "player@email.com",
  "password": "StrongPassword123",
  "gamerTag": "Shadow"
}

Response

{
  "userId": "uuid"
}

Validation

- Unique email
- Unique gamerTag

Errors

- EMAIL_EXISTS

---

Login

POST /auth/login

Response

{
  "accessToken": "...",
  "refreshToken": "...",
  "role": "PLAYER"
}

---

Refresh Token

POST /auth/refresh

---

Logout

POST /auth/logout

Side Effect

Revokes refresh token.

---

3. USER / PROFILE

Get My Profile

GET /users/me

Roles:

- Authenticated

Response

{
  "id": "uuid",
  "email": "",
  "role": "PLAYER"
}

---

Update Profile

PATCH /users/me

Request

{
  "displayName": "Shadow",
  "country": "NG"
}

---

4. PLAYER

Get Player

GET /players/{playerId}

---

Player Career

GET /players/{playerId}/career

Returns

- seasons
- rankings
- trophies
- MVP awards

---

Recruitment Pool

GET /players/recruitment-pool

Filters

?division=
?region=

Roles

- Club Managers
- Admins

---

5. CLUBS

Create Club

POST /clubs

Roles

- Player

Request

{
  "name": "Lagos Titans",
  "description": "Competitive club"
}

Status Created:

PENDING_APPROVAL

Side Effects

- Review queue created

---

Get Club

GET /clubs/{clubId}

---

Update Club

PATCH /clubs/{clubId}

Roles

- Club Manager
- Admin

---

Club Roster

GET /clubs/{clubId}/roster

---

Approve Club

POST /clubs/{clubId}/approve

Roles

- Commissioner
- HQ

Side Effect

Club status becomes:

ACTIVE

---

6. CLUB APPLICATIONS & MEMBERSHIP

Apply To Club

POST /clubs/{clubId}/applications

Roles

- Player

Request

{
  "message": "Interested in joining."
}

---

List Applications

GET /clubs/{clubId}/applications

Roles

- Club Manager

---

Accept Application

POST /applications/{applicationId}/accept

Side Effects

- Membership created
- Other active applications closed

---

Reject Application

POST /applications/{applicationId}/reject

---

Remove Player

DELETE /clubs/{clubId}/members/{playerId}

Roles

- Club Manager
- Admin

---

7. SEASONS

Create Season

POST /seasons

Roles

- Commissioner
- HQ

Request

{
  "name": "Season 1",
  "startDate": "",
  "endDate": ""
}

Status

DRAFT

---

Publish Season

POST /seasons/{seasonId}/publish

Transition

DRAFT → REGISTRATION_OPEN

---

Get Seasons

GET /seasons

Filters

?status=

---

Season Standings

GET /seasons/{seasonId}/standings

---

8. DIVISIONS

Create Division

POST /divisions

Roles

- Commissioner
- HQ

Request

{
  "seasonId": "uuid",
  "name": "Division A"
}

---

List Divisions

GET /divisions

---

Division Standings

GET /divisions/{divisionId}/standings

---

9. FIXTURES / MATCHES

Create Fixture

POST /matches

Roles

- Operator
- Commissioner
- HQ

Request

{
  "seasonId": "uuid",
  "divisionId": "uuid",
  "homePlayerId": "uuid",
  "awayPlayerId": "uuid",
  "scheduledAt": ""
}

Initial State

SCHEDULED

---

List Matches

GET /matches

Filters

?seasonId=
?divisionId=
?status=
?playerId=

---

Get Match

GET /matches/{matchId}

---

Check-In

POST /matches/{matchId}/check-in

Roles

- Assigned players

Response

{
  "status": "CHECKED_IN"
}

Validation

- Check-in window open

Errors

- CHECKIN_CLOSED

---

Mark No Show

POST /matches/{matchId}/no-show

Roles

- Operator

Side Effects

- Forfeit review started

---

10. RESULT SUBMISSION

Submit Result

POST /matches/{matchId}/results

Roles

- Match participant

Request

{
  "winnerPlayerId": "uuid",
  "score": "2-0",
  "evidenceUrls": [
    "https://..."
  ]
}

State

AWAITING_CONFIRMATION

Validation

- Match completed
- Submission window open

---

View Submission

GET /matches/{matchId}/results

---

11. RESULT CONFIRMATION

Confirm Result

POST /results/{resultId}/confirm

Roles

- Opponent

Response

{
  "status": "CONFIRMED"
}

Side Effects

- Standings updated
- Stats updated

---

Reject Result

POST /results/{resultId}/reject

Request

{
  "reason": "Incorrect score"
}

Side Effects

- Dispute draft generated

---

12. DISPUTES

Create Dispute

POST /disputes

Roles

- Match participant
- Club Manager

Request

{
  "matchId": "uuid",
  "reason": "Opponent submitted false score",
  "evidenceUrls": []
}

Initial State

OPEN

---

List Disputes

GET /disputes

Filters

?status=
?seasonId=

---

Get Dispute

GET /disputes/{disputeId}

---

Resolve Dispute

POST /disputes/{disputeId}/resolve

Roles

- Operator
- Commissioner
- HQ

Request

{
  "decision": "UPHELD",
  "notes": "Evidence supports claim"
}

State

OPEN → RESOLVED

Side Effects

- Result corrected if needed
- Penalty may be created

---

13. PENALTIES / SANCTIONS

Create Penalty

POST /penalties

Roles

- Commissioner
- HQ

Request

{
  "targetType": "PLAYER",
  "targetId": "uuid",
  "penaltyType": "WARNING",
  "reason": "No-show"
}

Penalty Types

WARNING
FORFEIT
POINT_DEDUCTION
SUSPENSION
BAN

---

List Penalties

GET /penalties

Filters

?playerId=
?clubId=

---

Appeal Penalty

POST /penalties/{penaltyId}/appeal

Roles

- Penalized party

---

14. NOTIFICATIONS

My Notifications

GET /notifications

---

Mark Read

POST /notifications/{notificationId}/read

---

Mark All Read

POST /notifications/read-all

---

Generated Events

- Fixture assigned
- Check-in reminder
- Result submitted
- Result confirmed
- Dispute opened
- Penalty issued

---

15. ADMIN / OPERATIONS

Dashboard Summary

GET /admin/dashboard

Roles

- Operator+

Returns

- active matches
- open disputes
- pending clubs
- penalties

---

Verify Player

POST /admin/players/{playerId}/verify

Roles

- Commissioner
- HQ

---

Suspend Player

POST /admin/players/{playerId}/suspend

Request

{
  "days": 30,
  "reason": "Misconduct"
}

Side Effects

- Player locked from league actions

---

Assign Club Manager

POST /admin/clubs/{clubId}/manager

---

Generate Fixtures

POST /admin/divisions/{divisionId}/generate-fixtures

Roles

- Commissioner
- HQ

Idempotency

One active schedule generation job per division.

---

16. AUDIT LOGS

Required for competitive integrity.

List Audit Events

GET /audit-logs

Roles

- Commissioner
- HQ

Filters

?entityType=
?entityId=
?actorId=

Audit Event

{
  "actorId": "",
  "action": "RESULT_APPROVED",
  "entityType": "MATCH",
  "entityId": "",
  "createdAt": ""
}

Logged Actions

- season creation
- fixture generation
- result approval
- dispute resolution
- penalty issuance
- club approval
- player suspension

---

17. LEADERBOARDS / STANDINGS

Global Leaderboard

GET /leaderboards

Filters

?seasonId=
?divisionId=

---

MVP Leaderboard

GET /leaderboards/mvp

---

Club Rankings

GET /leaderboards/clubs

---

Player Rankings

GET /leaderboards/players

Response

{
  "rank": 1,
  "playerId": "uuid",
  "wins": 10,
  "losses": 2,
  "points": 30
}

---

MATCH WORKFLOW

SCHEDULED
    ↓
CHECKIN_OPEN
    ↓
CHECKED_IN
    ↓
IN_PROGRESS
    ↓
COMPLETED
    ↓
RESULT_SUBMITTED
    ↓
AWAITING_CONFIRMATION
    ↓
CONFIRMED

Alternative Paths

AWAITING_CONFIRMATION
    ↓
DISPUTED
    ↓
RESOLVED

CHECKIN_OPEN
    ↓
NO_SHOW_REVIEW
    ↓
FORFEIT

---

IDEMPOTENCY RULES

Must support Idempotency-Key header for:

- Create Club
- Create Season
- Create Match
- Submit Result
- Create Dispute
- Create Penalty

Duplicate requests with same key return original response.

---

MVP PRIORITY ENDPOINTS

Highest priority implementation order:

1. Authentication
2. Seasons
3. Divisions
4. Matches
5. Result Submission
6. Result Confirmation
7. Disputes
8. Penalties
9. Club Management
10. Standings
11. Notifications
12. Audit Logs
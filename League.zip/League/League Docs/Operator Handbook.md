NexGen Esport Operator Handbook
MVP Version 1 - Operational Manual
Esports League Operations

Manual Coverage 
• Operator mission and purpose
• Authority hierarchy
• Code of conduct
• Daily operating workflow
• Check-in management
• Match-window management
• Result verification
• Evidence standards
• Dispute handling
• No-show policy
• Disconnect policy
• Penalty application
• Escalation matrix
• Season support
• Communication standards
• Recordkeeping
• Performance standards
• Misconduct rules
• Emergency procedures
• Quick checklist

1. Purpose and Scope
This handbook defines how NexGen operators run the league at the MVP stage. It explains daily responsibilities, match operations, result verification, dispute handling, penalties, escalation, and season support.
Operators are neither spectators nor content creators. They are the human control layer that keeps the league moving.
2. Operator Mission
• Protect competitive integrity.
• Keep matches on schedule.
• Verify results using evidence.
• Resolve disputes quickly and fairly.
• Apply rules consistently.
• Escalate serious issues to commissioners or NexGen HQ.
3. Authority Structure
Role
Main Function
Authority Level
NexGen HQ
Final authority over rulings, policy, bans, and season changes.
Highest
League Commissioner
Supervises operators, reviews escalations, and oversees divisions.
High
Match Operator
Verifies results, handles no-shows, reviews evidence, and updates statuses.
Medium
Moderator
Manages conduct, warnings, community support, and basic discipline.
Support
4. Operator Code of Conduct
• Stay neutral. Do not favour clubs, friends, or active players.
• Be factual. Decide using evidence, not assumptions.
• Be timely. Delayed decisions hurt the league.
• Be professional. No insults, threats, sarcasm, or public arguing.
• Do not leak private reports, disputes, or internal decisions.
• Do not override the rulebook without escalation.
5. Daily Operations Workflow
5.1 Before Match Day
• Review the fixtures assigned to your division or region.
• Check that every fixture has the correct participants, match ID, and deadlines.
• Confirm that players or club managers have received fixture notifications.
• Flag missing profiles, missing clubs, or inactive users before match time.
5.2 Check-In Window
The check-in window opens 24 hours before match time and closes 30 minutes before match time.
• Confirm that both sides have checked in.
• If one side has not checked in, send a reminder if time allows.
• If the check-in deadline passes, mark the match as at risk and prepare a forfeit review.
• Record every exception in the operator log.
5.3 Match Window
The official match window lasts 1 hour.
• Monitor match completion status.
• Do not let matches linger indefinitely.
• If a match starts late, verify whether it is still within league tolerance.
• If timing abuse is visible, escalate immediately.
5.4 Submission Window
After the match closes, the submission grace period is 15 minutes.
• Verify that the result was submitted on time.
• Reject or escalate late submissions according to policy.
• Do not accept verbal-only results without evidence except in emergency cases approved by HQ.
6. Result Verification Workflow
• Receive submitted score and evidence.
• Confirm the fixture ID matches the correct participants.
• Check the screenshot or clip for clarity, score, and match details.
• Check whether the opponent confirmed the result.
• Approve the result if the evidence is consistent and uncontested.
• Escalate if the result is disputed, incomplete, or suspicious.
6.1 Evidence Standards
• A valid screenshot must show the score clearly.
• Match identity should be visible or inferable from the submission context.
• Blurry, cropped, edited, or obviously manipulated evidence should be rejected.
• Operators should request additional proof only when necessary.
• If evidence is weak but the situation is straightforward, escalate rather than guessing.
6.2 Acceptable Evidence Types
• Final score screenshot
• Match summary screen
• Approved replay or clip
• Opponent confirmation in the platform
7. Dispute Handling Procedure
Disputes must be handled calmly, quickly, and using evidence.
• Identify the dispute type: score dispute, no-show, disconnect, rule violation, or false reporting.
• Review both player statements.
• Check all submitted evidence.
• Compare the case to the rulebook.
• Issue a decision or escalate.
• Record the final outcome in the league log.
7.1 Common Dispute Types
• Wrong score submitted
• Opponent did not appear
• Opponent submitted fake evidence
• Disconnect during match
• Illegal game settings
• Late match reporting
• Harassment or intimidation during match
7.2 Dispute Decision Rules
• If the evidence is clear, rule directly.
• If evidence is incomplete, escalate.
• If both sides are uncooperative, follow the forfeit or no-show policy.
• Do not drag a dispute beyond the approved review window unless HQ allows it.
8. No-Show and Forfeit Policy
A no-show happens when a participant fails to appear, fails to check in, or refuses to continue without a valid reason.
• First offense may receive a warning or controlled forfeit depending on the competition.
• Repeated no-shows should attract point deductions or suspension.
• If one participant disappears after check-in, the operator must mark the case quickly and clearly.
• Never leave a fixture unresolved just because nobody wants to be the one to decide.
9. Disconnect Policy
• A disconnect does not automatically cancel a result.
• Operators must check timing, screenshots, and whether abuse is obvious.
• If the disconnect happened very early and the rules require a replay, restart the fixture.
• If the disconnect pattern looks deliberate, escalate for penalty review.
• If the evidence is unclear, do not guess. Escalate.
10. Penalty Application Guide
Penalty
Typical Trigger
Operator Action
Warning
Minor first offense
Record and notify.
Point Deduction
• Match Forfeit: No-show, no Result evidence, major timing breach

• Repeated minor violations or repeated delays
• Assign or escalate for approval.

• Record deduction after review
Suspension
Cheating, abuse, repeated bad conduct
Escalate to commissioner/HQ.
Permanent Ban
Severe or repeated serious misconduct
HQ decision only.
11. Escalation Matrix
• Match Operator handles the first review.
• The commissioner handles escalated or complex cases.
• NexGen HQ handles final disputes, serious bans, and rule exceptions.
11.1 Escalate Immediately When
• There is evidence of cheating.
• A club manager is involved in the dispute.
• The case could affect season standings significantly.
• The evidence is inconsistent and the ruling is not obvious.
• A player challenges operator authority in a serious way.
12. Season Operations Support
• Assist with fixture release and notification.
• Track unresolved matches during the season.
• Update standings after approved results.
• Identify inactive players and clubs.
• Support playoff scheduling and season closure.
• Ensure season archive records are complete.
13. Communication Standards
• Use short, factual messages.
• Avoid emotional arguments.
• Explain decisions in plain language.
• Reference the rulebook when needed.
• Do not discuss private matters in public channels.
• Treat clubs and players with equal professionalism.
14. Recordkeeping Requirements
• Every decision must be logged.
• All disputes must have a clear outcome.
• Penalties must be documented with reason.
• Important communications should be preserved.
• Season-related actions must be traceable.
15. Operator Performance Standards
• Fast response to active issues.
• Accurate rulings.
• Consistency with the rulebook.
• Low error rate.
• Professional conduct.
• No bias complaints.
16. Operator Misconduct
• Favoring a friend or club.
• Ignoring evidence.
• Changing results without authority.
• Leaking disputes.
• Harassing participants.
• Abusing access to punish or protect users.
Operators found guilty of misconduct may be warned, suspended, removed, or permanently barred from league duties.
17. Emergency Procedures
• If the system is down, pause critical decisions and preserve records manually.
• If a major dispute affects a top fixture, escalate quickly rather than guessing.
• If a mass delay or event failure occurs, HQ may extend deadlines or reschedule fixtures.
• If abuse becomes public or severe, lock the case and escalate immediately.
18. Operator Quick Checklist
• Review today’s fixtures.
• Check check-ins.
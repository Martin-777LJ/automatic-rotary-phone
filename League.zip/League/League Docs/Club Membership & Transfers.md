Club Membership & Transfers (MVP)

Purpose

Defines how players join clubs, leave clubs, and become eligible to compete during a season.

---

Membership Structure

CM-01: Player Membership Rule

A player may belong to only one club at a time.

Rule

1 Player = 1 Active Club

A player cannot:

Join multiple clubs simultaneously

Compete for multiple clubs in the same season

Hold memberships in competing clubs

---

CM-02: Club Roles

Club Owner

Responsible for:

Club management

Roster management

League communication

Fee payments

Rule compliance

Maximum:

1 Club Owner

---

Club Member

Responsible for:

Match participation

Compliance with league rules

Maintaining eligibility

Maximum:

4 Additional Members

MVP roster size:

3–5 Players

---

Joining a Club

CM-03: Invitation Process

Players cannot be added automatically.

Workflow

Club Owner Sends Invite
        ↓
Player Receives Invite
        ↓
Player Accepts
        ↓
Membership Created

All invitations must be explicitly accepted.

---

CM-04: Eligibility Requirements

To join a club, a player must:

Have a NexGen account

Be verified

Have no active suspension

Not belong to another club

---

Recruitment Pool

CM-05: Recruitment Pool Eligibility

The recruitment pool exists to help clubs discover available players.

Players enter the pool if:

Account is verified

Not currently in a club

No active sanctions

Active during the current season

---

Elite Recruitment Rule

Elite players who are not attached to clubs are automatically added to the recruitment pool.

This supports club scouting and recruitment.

---

Leaving a Club

CM-06: Voluntary Departure

Players may leave a club.

Restrictions apply.

Allowed

Before roster lock:

Player may leave freely.

Restricted

After roster lock:

Player cannot leave without admin approval.

This prevents roster manipulation.

---

Removal from Club

CM-07: Club Removal

Club owners may remove members.

Conditions

Allowed before roster lock.

After roster lock:

Removal requires League Operations approval.

Justification must be provided.

Examples:

Inactivity

Rule violations

Player misconduct

---

Roster Lock

CM-08: Roster Lock

Roster lock occurs before league kickoff.

MVP Rule

72 Hours Before Week 1

After roster lock:

No new players

No transfers

No replacements

Unless approved by League Operations.

---

Emergency Replacements

CM-09: Replacement Requests

A club may request a replacement player if:

A player permanently leaves

A player is banned

A player becomes unavailable long-term

Approval Required

League Operations must approve the request.

The replacement must:

Meet eligibility requirements

Not have played for another club that season

---

Transfer System

CM-10: Transfers

For MVP:

No Mid-Season Transfers

Reason:

Simpler operations

Easier enforcement

Reduced fraud risk

Transfer windows can be introduced in Season 2.

---

Club Disbandment

CM-11: Club Closure

A club may request closure.

Conditions

Allowed only when:

No active season participation

No unresolved disputes

No outstanding sanctions

---

During Active Season

Club closure requests are not allowed.

The club must finish or withdraw through League Operations.

---

Membership Violations

CM-12: Illegal Membership

Violations include:

Multiple club memberships

Shared accounts

Playing for another club

Impersonation

Penalties may include:

Match forfeiture

Suspension

Club sanctions

Season disqualification

---

Membership Status Lifecycle

Invited
↓
Accepted
↓
Active
↓
Roster Locked
↓
Released / Departed

---

MVP Principle

The MVP should prioritize stability over flexibility.

That means:

One player → one club

No mid-season transfers

Fixed rosters

Recruitment only before roster lock

League Operations approval for exceptional cases
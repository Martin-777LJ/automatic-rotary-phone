1) Season 1 League Format Definition

Season 1 structure: NexGen Football Division

This is a club-based league, not a free-for-all player ladder.

Format

8 clubs

Single table

1 match per club per week

7 regular-season weeks

Week 8 = playoffs, finals, awards, and season close

Club roster

Minimum: 3 players

Maximum: 5 registered players

Club manager required

1 club = 1 official competitive identity

Standings

Win = 3 points

Draw = 1 point

Loss = 0 points

Forfeit loss = 0 points + penalty review

End-of-season outcome

Top 4 → playoffs

Bottom 2 → relegation risk / probation review

Champion → season title + rewards

No club gets promoted/relegated mid-season

That is the cleanest MVP format. It is simple, visible, and operationally manageable.

---

2) Ranking System

You are right: this is not XP.
This is a competitive classification system.

Player classes

Amateur

New or low-activity players

Entry point into the ecosystem

Competitive

Consistent active players

Valid match history

Elite

High-level division players

Strong results and reputation

Verified Pro

Top recognized competitors

Manual approval or elite performance threshold

Reputation system

Use a Reputation Score, not XP.

Reputation is earned from:

Match completion

Fair play

Activity consistency

Low dispute rate

Verification status

No-show avoidance

Suggested scoring model

Use a 100-point reputation score:

Match completion: 35

Fair play: 25

Activity consistency: 20

Low dispute rate: 10

Verification/compliance: 10

Promotion logic

Amateur → Competitive

Verified account

Minimum match participation

No serious sanctions

Competitive → Elite

Strong season performance

Reputation above threshold

No active violations

Elite → Verified Pro

Top division performance

Consistent reliability

Manual approval by NexGen HQ / League Ops

Recruitment pool rule

This part is now clean:

Only players in the top division class are auto-added to the recruitment pool

Only if they are:

not already in a club

verified

not sanctioned

active and eligible

So the recruitment pool is a visibility layer, not a new rank.

---

3) Club Creation Requirements

Club creation should not be open to everyone.

To create a club, the applicant must have:

Full identity verification

Business verification

Minimum balance threshold

Creation fee: $10 MVP

Minimum roster: 3 players

Club name

Club logo

Region/location

Accepted league rules

No active sanctions

Approval process

User submits club request

NexGen manually reviews

If approved, club enters probationary active status

If rejected, user must correct the issues and reapply

Maximum roster size

For MVP, keep it tight:

5 registered players maximum

Optional reserve slots can be added later, but not now

That keeps administration sane.

---

4) Season Calendar

Your calendar needs separation between registration period and season period. Do not mix them.

Official Season 1 calendar

Registration Open: 8 weeks

Verification Window: during registration, final lock in the last 3 days

Roster Lock: 72 hours before league kickoff

Regular Season: 7 weeks

Playoffs + Finals + Awards: 1 week

This means:

Open registration is 2 months before season start

Once the season starts, rosters are fixed

No late club formation after lock unless NexGen HQ approves it

Final structure

Weeks -8 to -1: Registration, identity checks, club approval

Week 0: Fixture release

Weeks 1–7: Match weeks

Week 8: Playoffs, finals, awards, archive

That is the official timing.

---

5) Rewards System

This must be visible, structured, and not random.

A. Ranking rewards

For player standing and reputation:

Badge/title

Profile feature

Priority recruitment visibility

Entry into higher division

Verified status boost

B. Seasonal rewards

For season performance:

Champion trophy

Runner-up recognition

MVP award

Best defender / best attacker / best club awards

Sponsor gifts or merchandise

C. Prize rewards

For final placements:

Fixed, announced reward pool

No hidden or variable reward logic

No gambling-like mechanics

D. Club rewards

For clubs:

Featured club placement

Club badge enhancement

Sponsor visibility

Priority approval for next season

Reduced next-season admin friction

Important rule

Rewards should be:

modest

announced upfront

performance-based

sustainable

No vague “maybe rewards later” system. That kills trust.

---

6) Anti-Fraud System

This is separate from anti-cheat. You are dealing with identity abuse, result abuse, and structure abuse.

A. Multiple accounts

Rule: one verified identity = one primary account

If a duplicate is found:

freeze the accounts

review identity links

suspend if intentional abuse is confirmed

B. Fake clubs

If a club is fake or created to manipulate the system:

reject the club

cancel pending approval

forfeit creation fee

suspend the applicant if deliberate fraud is proven

C. Fake results

If a fake result is submitted:

mark match as disputed

require evidence

if false reporting is confirmed:

forfeit the match

deduct points

suspend the offender

D. Collusion

This includes:

coordinated fake forfeits

result manipulation

same person controlling multiple clubs

intentional standings distortion

Penalty:

match forfeits

point deductions

club disqualification

season ban for serious cases

MVP fraud rule

If evidence is missing and both sides are lying, the system should not guess.
It should default to:

under review

operator decision

documented ruling
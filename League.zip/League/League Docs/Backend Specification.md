NexGen Esport MVP Backend Service Architecture Specification

Executive Decision

Architecture Choice: Modular Monolith

Recommendation: Modular Monolith

Do not build microservices.

The NexGen MVP is not a Netflix-scale platform. It is a league operations platform where:

Most workflows are tightly connected

Admin operations control everything

League rules affect multiple domains simultaneously

Small team maintenance matters more than theoretical scalability

Why Modular Monolith Fits NexGen

The system revolves around:

Players

Clubs

Seasons

Fixtures

Results

Disputes

Penalties

Rankings

Almost every operation touches multiple domains.

Example:

Result Approved

→ Match updated
→ Standings updated
→ Rankings updated
→ Club stats updated
→ Rewards recalculated
→ Notifications sent
→ Audit log created

Splitting this into microservices creates unnecessary complexity.

For MVP:

Single Deployment Single Database Strong Module Boundaries Event-Based Internal Communication

This gives:

Fast development

Easier debugging

Lower hosting costs

Easier onboarding

Easier operational control

---

High Level Architecture

API Layer

├── Auth Module
├── User Module
├── Player Module
├── Club Module
├── Season Module
├── Match Module
├── Dispute Module
├── Penalty Module
├── Standings Module
├── Rewards Module
├── Notification Module
└── Admin Module

----------------------------

Application Layer

Domain Services

Event Bus

Job Queue

----------------------------

Infrastructure Layer

PostgreSQL
Redis
Object Storage
Realtime Gateway
Email/Push Providers
Audit Log Store

---

Module Ownership Rules

Every module owns its own business logic.

Never place league rules inside:

Controllers

API routes

Server actions

Cron jobs

Only domain services should enforce league rules.

---

Shared Infrastructure Modules

Authentication Utility

Responsibility

Identity verification.

Owns

Sessions

Refresh tokens

Login state

Never Owns

League permissions

Club membership

---

Authorization Utility

Responsibility

Role enforcement.

Examples:

Player

Manager

Moderator

Operator

Commissioner

HQ Admin

Owns

Role checks

Permission checks

Never Owns

User profiles

Match logic

---

Validation Utility

Responsibility

Input validation.

Examples:

Score validation

Fixture validation

Season creation validation

Never Owns

Business rules.

---

Audit Logging Utility

Responsibility

Permanent activity tracking.

Examples:

Result approved

Penalty issued

Club approved

Dispute resolved

Never Owns

Operational data.

---

1. Authentication Module

Responsibility

Identity management.

Inputs

Login request

Registration request

Refresh token

Outputs

JWT

Session

User identity

Dependencies

User Module

Emits

UserRegistered

UserLoggedIn

Consumes

None

Owns

Credentials

Sessions

Never Owns

Profiles

Clubs

Matches

Failure Modes

Invalid credentials

Expired tokens

Duplicate accounts

---

2. User Module

Responsibility

Core account management.

Inputs

Registration

Profile updates

Outputs

User profile

Dependencies

Auth

Emits

UserCreated

UserUpdated

Consumes

UserRegistered

Owns

User

Profile

Never Owns

Player career data

Club membership

Failure Modes

Duplicate usernames

Invalid profile data

---

3. Player Module

Responsibility

Competitive player identity.

Inputs

Player registration

Division assignment

Outputs

Player record

Career history

Dependencies

User

Club

Season

Emits

PlayerCreated

PlayerPromoted

PlayerSuspended

Consumes

SeasonCompleted

PenaltyIssued

Owns

Player stats

Reputation

Division

Career history

Never Owns

Match results

Standings

---

4. Club Engine

Responsibility

Club lifecycle management.

Inputs

Club applications

Recruitment actions

Transfers

Outputs

Club state

Dependencies

Player

Season

Emits

ClubCreated

ClubApproved

ClubActivated

ClubDissolved

Consumes

PlayerJoinedClub

PlayerLeftClub

Owns

Clubs

Rosters

Club status

Never Owns

Match records

Penalties

Failure Modes

Insufficient roster

Duplicate club names

Manager conflict

---

5. Season Engine

Responsibility

Entire season lifecycle.

Inputs

Season creation

Season start

Season end

Outputs

Active competition structure

Dependencies

Match Engine

Standings Engine

Emits

SeasonCreated

SeasonStarted

SeasonEnded

Consumes

FixturesGenerated

Owns

Seasons

Divisions

Groups

Never Owns

Results

Disputes

Failure Modes

Invalid schedule

Missing participants

---

6. Match Operations Engine

Most critical operational engine.

Responsibility

Fixture lifecycle.

Inputs

Fixture creation

Check-in

Result submission

Confirmation

Outputs

Match status

Dependencies

Season

Player

Club

Emits

FixtureCreated

CheckInOpened

MatchStarted

ResultSubmitted

ResultApproved

MatchForfeited

Consumes

SeasonStarted

PenaltyIssued

Owns

Fixtures

Results

Evidence

Never Owns

Rankings

Rewards

Failure Modes

Missing evidence

Conflicting results

No-show

---

7. Dispute Engine

Responsibility

Formal challenge process.

Inputs

Dispute submissions

Outputs

Resolution

Dependencies

Match Engine

Penalty Engine

Emits

DisputeOpened

DisputeEscalated

DisputeResolved

Consumes

ResultSubmitted

PenaltyIssued

Owns

Disputes

Evidence reviews

Never Owns

Match results directly

Failure Modes

Missing evidence

Escalation backlog

---

8. Penalty Engine

Responsibility

Rule enforcement.

Inputs

Operator actions

Dispute outcomes

No-shows

Outputs

Warnings

Suspensions

Forfeits

Dependencies

Player

Club

Emits

PenaltyIssued

SuspensionApplied

BanApplied

Consumes

DisputeResolved

NoShowDetected

Owns

Penalty records

Suspension records

Never Owns

Match records

Failure Modes

Duplicate penalties

Incorrect sanction level

---

9. Standings & Ranking Engine

Responsibility

League calculations.

Inputs

Approved results

Outputs

Rankings

Standings

Leaderboards

Dependencies

Match Engine

Season Engine

Emits

StandingsUpdated

RankingsUpdated

Consumes

ResultApproved

Owns

Tables

Rankings

Leaderboards

Never Owns

Raw results

Failure Modes

Calculation errors

Corrupt standings

---

10. Reward Distribution Engine

Responsibility

Season rewards.

Inputs

Season completion

Outputs

Rewards

MVP awards

Dependencies

Standings

Player

Emits

RewardsCalculated

RewardGranted

Consumes

SeasonEnded

Owns

Reward records

Never Owns

Season standings

Failure Modes

Duplicate payouts

Incorrect eligibility

---

11. Notification Engine

Responsibility

Communication layer.

Inputs

Domain events

Outputs

Push notifications

Email

In-app alerts

Dependencies

All modules

Emits

None

Consumes

Almost all events

Examples:

MatchAssigned

DisputeOpened

PenaltyIssued

Owns

Notification history

Never Owns

Business state

Failure Modes

Provider downtime

Delivery failures

---

12. Audit Engine

Responsibility

Compliance and traceability.

Inputs

Every administrative action.

Outputs

Immutable logs.

Dependencies

All modules.

Emits

None

Consumes

Administrative events.

Owns

Audit records

Never Owns

Business entities

---

Realtime/Event Layer

Recommendation

Use:

Supabase Realtime OR

Pusher

Only for:

Live standings

Match updates

Notifications

Admin dashboards

Never make realtime the source of truth.

Database remains source of truth.

---

Internal Event Bus

Use simple domain events.

Examples:

ResultApproved

→ Update Standings
→ Update Rankings
→ Notify Players
→ Create Audit Entry
→ Check Rewards

No Kafka. No RabbitMQ.

Simple in-process event dispatcher.

---

Synchronous Operations

Must complete immediately.

Authentication

Login

Logout

Match Submission

Submit result

Club Application

Create application

Dispute Submission

Open dispute

Admin Actions

Approve result

Issue penalty

---

Asynchronous Operations

Move to queue/jobs.

Notifications

Email Push

Standings Rebuild

Large recalculations

Reward Calculations

End-of-season processing

Audit Export

Reports

Scheduled Operations

Check-in opening

Check-in closing

Submission deadline handling

No-show detection

Season reminders

---

Jobs Layer

Use:

Vercel Cron

Cloud Scheduler

Background Workers

Jobs:

Open Check-In Window
Close Check-In Window
Submission Deadline Check
No-Show Detection
Auto Confirmation
Season Start Tasks
Season End Tasks
Reward Distribution

---

Server Actions vs API vs Jobs

Server Actions

Use only for internal admin UI actions.

Examples:

Approve club

Approve result

Issue penalty

---

REST APIs

Use for:

Mobile app

Public frontend

Future integrations

All domain operations should be API-driven.

---

Background Jobs

Use for:

Scheduled workflows

Notifications

Recalculations

---

Final MVP Architecture Summary

MODULAR MONOLITH

Modules

Auth
Users
Players
Clubs
Seasons
Matches
Disputes
Penalties
Standings
Rewards
Notifications
Audit
Admin

Infrastructure

PostgreSQL
Redis
Object Storage
Realtime Layer
Job Queue

Pattern

REST APIs
Domain Services
Internal Event Bus
Background Jobs

NO Microservices
NO Service Mesh
NO Distributed Transactions
NO Event Sourcing
NO CQRS

Optimize for:
Operational Control
League Integrity
Admin Efficiency
Small Team Maintainability
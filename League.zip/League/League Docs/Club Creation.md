Club Creation Requirements (MVP)
Purpose
Club creation is restricted to maintain league integrity, reduce fraud, and ensure club owners have sufficient commitment to participate in NexGen competitions.
Eligibility Requirements
A user may create a club only if all requirements below are satisfied.
CR-01: Full Identity Verification
The applicant must complete NexGen MVP Identity Verification.
Verification Requirements
Required:
• Full legal name
• Date of birth
• Government-issued identification
• Selfie verification
• Verified email address
• Verified phone number
Status Required
Verification Status = VERIFIED 
Users with pending, rejected, or expired verification cannot create clubs.
CR-02: Minimum Balance Threshold
The applicant must maintain the required minimum wallet balance before club creation.
MVP Threshold
Minimum Balance = $2 USD equivalent 
Purpose:
• Demonstrates account legitimacy
• Reduces spam club creation
• Supports league operational costs
Balance must be available before submission.
CR-03: Club Creation Fee
A non-refundable club creation fee is charged when the application is approved.
MVP Fee
Club Creation Fee = $2 USD 
Notes
• Charged once per club.
• Fee is not refunded if the club later becomes inactive.
• Fee may be adjusted in future seasons.
CR-04: Minimum Roster Requirement
A club must have the minimum required number of players before approval.
MVP Requirement
Minimum Players = 3 
All players must:
• Have registered NexGen accounts
• Accept club invitations
• Not be under suspension
Approval Rule
A club cannot be approved with fewer than three confirmed members.
Club Information Requirements
CR-05: Club Name
A unique club name is required.
Rules
Must:
• Be unique platform-wide
• Contain 3–30 characters
• Not contain offensive content
• Not impersonate existing organizations
Examples:
✅ Port Harcourt Titans
✅ Delta Wolves
❌ Admin Team
❌ FIFA Official Club
CR-06: Club Logo
A club logo is required.
Rules
Must:
• Be uploaded during creation
• Meet image size requirements
• Not contain prohibited content
• Not infringe known trademarks
Default logos should not be allowed for competitive clubs.
CR-07: Region / Location
A club must declare a primary operating region.
Examples
• Rivers State
• Lagos State
• Abuja
• Delta State
Purpose:
• Regional competitions
• Local rankings
• Future city/state leagues
A club may only have one primary region.
Compliance Requirements
CR-08: League Rule Acceptance
The club owner must accept:
• League Constitution
• Competition Rules
• Fair Play Policy
• Anti-Fraud Policy
• Dispute Resolution Policy
Acceptance is recorded with:
• User ID
• Date
• Timestamp
CR-09: No Active Sanctions
The applicant must not have active disciplinary actions.
Ineligible Statuses
• Suspended
• Banned
• Fraud Investigation
• Account Restriction
Eligibility Rule
Sanction Status = NONE 
Required for approval.
Approval Workflow
Submit Application ↓ Identity Verification Check ↓ Balance Verification ↓ Roster Verification ↓ Compliance Verification ↓ Admin Review ↓ Approved / Rejected 
Club Limits (MVP)
Minimum Roster
3 Players 
Maximum Roster
5 Players 
Club Ownership
1 User = 1 Club Ownership 
A user cannot own multiple clubs during the same season.
Club Status Lifecycle
Draft ↓ Submitted ↓ Under Review ↓ Approved ↓ Active ↓ Suspended (if sanctioned) ↓ Archived 
This structure is sufficient for the MVP while providing enough controls to prevent fake clubs, duplicate ownership, and low-quality registrations. The next section that should be defined is Club Membership & Transfers, because it directly affects roster locks, recruitment, player movement, and season operations.
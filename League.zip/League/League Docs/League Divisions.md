League Divisions & Player Classification (MVP)

Purpose

Defines how players are categorized, how progression works, and how the future division system will expand without requiring major architectural changes.

This system is not a level system and not an XP system.

It is a competitive classification framework.

---

Core Principles

Player classification should be determined by:

Competitive performance

Activity consistency

Reputation

League participation

Verification status

Not by:

Time spent on platform

Login streaks

XP grinding

Cosmetic achievements

---

Player Classification Structure

PC-01: Amateur

Entry-level competitors.

Characteristics

New players

Limited competitive history

First-time league participants

Developing competitive record

Eligibility

Default classification upon account approval.

Starting Classification = Amateur

---

PC-02: Competitive

Established active competitors.

Characteristics

Consistent participation

Completed multiple league matches

Good standing within the platform

Proven reliability

Requirements

Must meet minimum activity and reputation standards.

Examples:

Consistent match participation

No major sanctions

Positive conduct record

---

PC-03: Elite

High-level competitors.

Characteristics

Top-performing players

Strong league history

Reliable participation record

Significant competitive achievements

Elite players become visible within recruitment systems.

Additional Benefits

Elite profile badge

Increased recruitment visibility

Priority scouting placement

---

PC-04: Verified Pro

Top recognized competitors.

Characteristics

Professional competitors

Tournament champions

Recognized esports athletes

League ambassadors

Verification

Verified Pro is not automatically granted.

Requires:

Identity verification

Competitive evidence

League Operations approval

---

Player Reputation System

PC-05: Reputation Score

Every player maintains a reputation profile.

Purpose:

Measure reliability

Reduce abuse

Support classification decisions

---

Positive Reputation Factors

Match Completion

Measures whether players finish scheduled matches.

Indicators:

Played matches

Completed matches

No forfeits

---

Fair Play

Measures sportsmanship.

Indicators:

No cheating reports

No harassment violations

No abusive conduct

---

Activity Consistency

Measures engagement.

Indicators:

Regular participation

Seasonal involvement

Club commitment

---

Low Dispute Rate

Measures reliability.

Indicators:

Few disputes

Few complaints

Accurate reporting

---

Negative Reputation Factors

Match No-Shows

Penalty for:

Missing scheduled matches

Repeated absences

---

Disciplinary Actions

Penalty for:

Rule violations

Suspensions

Fraud investigations

---

Abuse Reports

Penalty for:

Toxic behavior

Harassment

Unsportsmanlike conduct

---

Classification Reviews

PC-06: Review Cycle

Classifications are reviewed at season end.

Review Timing

End of Every Season

This prevents constant movement during active competition.

---

Promotion Rules

PC-07: Amateur → Competitive

Requirements:

Verified account

Active participation

Good reputation standing

Completed season requirements

---

PC-08: Competitive → Elite

Requirements:

Strong season performance

High reputation standing

League participation history

No active sanctions

---

PC-09: Elite → Verified Pro

Requirements:

Exceptional performance

Recognition by League Operations

Compliance history

Manual approval

---

Demotion Rules

PC-10: Competitive → Amateur

Possible if:

Long-term inactivity

Repeated violations

Failure to maintain requirements

---

PC-11: Elite → Competitive

Possible if:

Performance declines significantly

Reputation falls below threshold

Serious disciplinary actions occur

---

PC-12: Verified Pro Review

Verified Pro status may be revoked if:

Fraud is discovered

Professional standing is misrepresented

Serious league violations occur

---

Recruitment Pool Integration

PC-13: Recruitment Eligibility

Players become visible to clubs when:

Verified

Active

Not currently attached to a club

No active sanctions

---

PC-14: Elite Recruitment Priority

Elite players not attached to clubs are automatically added to the Recruitment Pool.

Purpose:

Encourage scouting

Improve club quality

Support player mobility

---

Future Division Alignment

Although MVP launches with a single league division, the classification system must support future divisions.

Future Structure

Division 1
Elite / Verified Pro

Division 2
Competitive

Division 3
Amateur

This allows future promotion and relegation systems without redesigning player classifications.

---

Player Lifecycle

Registered User
        ↓
Amateur
        ↓
Competitive
        ↓
Elite
        ↓
Verified Pro

Demotion can occur at any stage if requirements are no longer met.

---

MVP Design Decision

For Season 1:

No player MMR

No Elo rating

No XP system

No skill points

No hidden ranking calculations

Only:

Classification

Reputation

League performance

Administrative review

This keeps the system transparent and easy to explain to players.
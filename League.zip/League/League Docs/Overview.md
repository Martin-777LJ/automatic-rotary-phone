NexGen Esport is:  

a digital esports league operating system. 

Focused initially on: 

football esports, 

league structure, 

clubs, 

seasonal competition, 

rankings, 

and organized competitive identity.
LAYER 1: GENERAL LEAGUE RULES (CORE CONSTITUTION)

These apply to ALL users.

Rules:

No cheating or exploits

No account sharing

No match fixing

Matches must follow official settings

Evidence required for results

NexGen has final authority

Purpose:

Defines what NexGen is

LAYER 2: STRUCTURE RULES (HOW THE LEAGUE EXISTS)

League Format:

Seasons (6–8 weeks MVP)

Divisions (Elite → Amateur)

Promotion/Relegation system

Weekly fixtures

Purpose:

Defines how competition works

LAYER 3: CLUB RULES

Club Creation:

Clubs can be created or requested

Must be approved by NexGen

Club Manager:

Proposed by club

Approved by NexGen

Responsible for discipline

Club Responsibilities:

manage roster

ensure match participation

resolve internal disputes first

maintain fair conduct

Club Limits:

minimum roster size (e.g. 3–5 players MVP stage)

no duplicate clubs

LAYER 4: PLAYER RULES

Player Responsibilities:

show up for matches

submit results when required

follow match rules

maintain fair play

Player Rights:

dispute unfair results

request admin review

change clubs (with rules)

Violations:

no-show penalties

cheating bans

toxic behavior sanctions

LAYER 5: MATCH RULES (VERY IMPORTANT)

Match Setup:

assigned fixture

time window (24–48h)

Result System:

player submits result

opponent confirms OR disputes

Evidence:

screenshot required (minimum)

optional video proof

Disconnection Rule:

replay or admin decision

LAYER 6: SEASON RULES

Season Flow:

start date

end date

fixtures schedule

Ranking System:

points system (3-1-0)

tie-breakers

Progression:

promotion

relegation

playoffs

LAYER 7: OFFICIALS SYSTEM

Roles:

1. League Admin (NexGen HQ)

final authority

rule changes

system control

2. League Operators

schedule matches

update standings

manage logistics

3. Referees / Match Officials

resolve disputes

verify evidence

enforce rules

LAYER 8: DISPUTE SYSTEM (CRITICAL CORE)

Step 1: Player Dispute

Triggered when:

no agreement on result

cheating accusation

missing evidence

Step 2: Club Mediation

Club tries to resolve internally

Step 3: League Review

Officials review:

screenshots

logs

player history

Step 4: Final Decision

NexGen ruling is FINAL

LAYER 9: ENFORCEMENT / PENALTY SYSTEM

Level 1: Warning

minor infractions

Level 2: Match Forfeit

failure to show evidence or rules breach

Level 3: Point Deduction

repeated offenses

Level 4: Suspension

cheating, abuse, manipulation

Level 5: Permanent Ban

severe violations or match fixing
1) Concise architecture overview

The MVP database should be split into five clean layers:

Identity & access

Accounts, player profiles, operator profiles, roles, permissions

Club layer

Clubs, club applications, club membership history

Competition layer

Seasons, divisions, division participation, fixtures, matches, match participants, results

Governance layer

Disputes, warnings, penalties, sanctions, audit logs

Progression layer

Standings, rankings, rewards, achievements

The important design decision is this: competition state is stored separately from account/profile state. That keeps the system sane when a user changes clubs, gets sanctioned, or moves through seasons.

---

2) Recommended enums

Use PostgreSQL enums or lookup tables for these values:

account_status: pending, active, suspended, banned, deleted

player_status: active, inactive, suspended, retired

operator_status: active, inactive, suspended

club_status: pending_review, approved, active, suspended, dissolved, rejected

membership_status: active, left, removed, suspended

application_status: pending, approved, rejected, withdrawn, expired

season_status: draft, registration_open, verification, roster_locked, active, playoffs, completed, archived

division_status: active, locked, completed, archived

division_member_status: registered, active, withdrawn, disqualified, promoted, relegated, eliminated

fixture_status: draft, published, cancelled, rescheduled

match_status: pending, check_in_open, ready, in_progress, awaiting_submission, awaiting_confirmation, under_review, verified, closed, voided

participant_status: pending, checked_in, late, no_show, disputed

confirmation_status: pending, confirmed, rejected

result_status: submitted, confirmed, rejected, disputed, voided

dispute_status: open, investigating, escalated, resolved, rejected, closed

warning_status: active, reversed, expired

penalty_status: active, reversed, expired

sanction_status: active, lifted, expired

notification_status: unread, read

reward_type: champion, runner_up, season_mvp, best_club, fair_play, top_scorer, promotion, special_award

achievement_type: badge, trophy, milestone, title

ranking_scope_type: global, season

---

3) Entity table

Entity	Purpose	PK	FKs	Key fields (required / optional)	Status fields / enums	Indexes / constraints	Soft delete

users	Master account record for login and identity	id UUID	—	Required: email, username, password_hash, account_status, email_verified; Optional: phone, avatar_url, display_name, last_login_at	account_status	Unique: email, username; Index: account_status	Yes (deleted_at)
player_profiles	Competitive profile for a user	id UUID	user_id -> users.id	Required: user_id, gamer_tag, region, verification_status, player_status, reputation_score; Optional: bio, preferred_game, avatar_url, cached stats (wins, losses, draws, goals_for, goals_against, no_show_count, mvp_count)	player_status, verification_status	Unique: user_id, gamer_tag; Index: player_status, verification_status	Yes (deleted_at)
operator_profiles	Operational identity for staff	id UUID	user_id -> users.id	Required: user_id, operator_role, status; Optional: assigned_division_id, assigned_region, notes	operator_role, operator_status	Unique: user_id; Index: operator_role, status	No
roles	RBAC role definitions	id UUID	—	Required: role_key, role_name; Optional: description, scope	—	Unique: role_key	No
permissions	Atomic access actions	id UUID	—	Required: permission_key, permission_name; Optional: description	—	Unique: permission_key	No
user_roles	Assign roles to users	id UUID	user_id, role_id	Required: user_id, role_id; Optional: assigned_by_user_id, assigned_at	—	Unique: (user_id, role_id); Index: user_id, role_id	No
role_permissions	Map roles to permissions	id UUID	role_id, permission_id	Required: role_id, permission_id	—	Unique: (role_id, permission_id)	No
clubs	Club identity, recruitment, and roster container	id UUID	created_by_user_id -> users.id, optional approved_by_user_id -> users.id	Required: club_name, slug, region, logo_url, club_status; Optional: description, founded_by_user_id, approved_at, rejection_reason	club_status	Unique: club_name, slug; Index: club_status, region	Yes (deleted_at)
club_members	Historical club membership records	id UUID	club_id -> clubs.id, player_profile_id -> player_profiles.id, optional approved_by_user_id -> users.id	Required: club_id, player_profile_id, role_in_club, joined_at; Optional: left_at, left_reason, membership_status, accepted_invite_at	membership_status	Partial unique: one active membership per player (player_profile_id where left_at IS NULL); Index: club_id, player_profile_id, membership_status	No
club_applications	Join club workflow and invite acceptance	id UUID	club_id -> clubs.id, player_profile_id -> player_profiles.id, optional submitted_by_user_id, reviewed_by_user_id	Required: club_id, player_profile_id, application_source, application_status, submitted_at; Optional: message, decision_reason, reviewed_at	application_status	Index: club_id, player_profile_id, application_status; Partial unique: one pending application per player per club	No
seasons	Season lifecycle and scheduling anchor	id UUID	created_by_user_id -> users.id	Required: season_number, name, registration_open_at, registration_close_at, roster_lock_at, start_at, end_at, season_status; Optional: description, archived_at	season_status	Unique: season_number; Index: season_status, start_at, end_at	No soft delete; use status + archive
divisions	Player divisions for a season	id UUID	season_id -> seasons.id	Required: season_id, name, level, division_type, division_status; Optional: capacity, sort_order	division_status	Unique: (season_id, level) or (season_id, name); Index: season_id, level, division_status	No
division_members (supporting but required)	Explicit season entry for each player	id UUID	season_id -> seasons.id, division_id -> divisions.id, player_profile_id -> player_profiles.id, optional club_id_snapshot -> clubs.id	Required: season_id, division_id, player_profile_id, registered_at, division_member_status; Optional: withdrawn_at, promoted_at, relegated_at, eliminated_at, notes	division_member_status	Unique: (season_id, player_profile_id); Index: division_id, player_profile_id, division_member_status	No
fixtures	Scheduled match assignment	id UUID	season_id -> seasons.id, division_id -> divisions.id, created_by_user_id -> users.id, player_a_profile_id -> player_profiles.id, player_b_profile_id -> player_profiles.id	Required: fixture_code, week_no, scheduled_at, check_in_open_at, check_in_close_at, submission_deadline_at, fixture_status; Optional: fixture_type, published_at, rescheduled_from_fixture_id, notes	fixture_status	Unique: fixture_code; Index: (season_id, division_id), scheduled_at, fixture_status; Constraint: player A != player B	No
matches	Operational record for an official fixture	id UUID	fixture_id -> fixtures.id	Required: fixture_id, match_status; Optional: started_at, ended_at, closed_at, admin_override_reason, operator_notes	match_status	Unique: fixture_id (1 match per fixture in MVP); Index: match_status	No
match_participants	Per-player operational state in a match	id UUID	match_id -> matches.id, player_profile_id -> player_profiles.id, optional club_id_snapshot -> clubs.id	Required: match_id, player_profile_id, side, participant_status; Optional: checked_in_at, confirmation_status, confirmed_at, submission_role, forfeit_flag	participant_status, confirmation_status	Unique: (match_id, player_profile_id); Unique: (match_id, side); Index: match_id, player_profile_id, participant_status	No
results	Official submitted score and evidence	id UUID	match_id -> matches.id, submitted_by_user_id -> users.id, submitted_by_player_profile_id -> player_profiles.id, optional verified_by_user_id -> users.id	Required: match_id, score_player_a, score_player_b, evidence_type, evidence_payload, submitted_at, result_status; Optional: winner_player_profile_id, verified_at, decision_notes, rejection_reason	result_status	Unique: match_id; Index: result_status, verified_by_user_id	No hard delete
disputes	Formal challenge against a match/result	id UUID	match_id -> matches.id, optional result_id -> results.id, opened_by_user_id -> users.id, opened_by_player_profile_id -> player_profiles.id, optional resolved_by_user_id -> users.id	Required: match_id, dispute_type, dispute_status, summary, opened_at; Optional: evidence_payload, resolution, resolution_notes, resolved_at, appeal_status, escalation_level	dispute_status, appeal_status	Partial unique: one active dispute per match (status IN open/investigating/escalated); Index: match_id, dispute_status	No hard delete
warnings	Minor disciplinary record	id UUID	target_user_id -> users.id, optional target_club_id -> clubs.id, issued_by_user_id -> users.id, optional match_id -> matches.id, dispute_id -> disputes.id	Required: reason, warning_status, issued_at; Optional: warning_level, expires_at, metadata_json	warning_status	Index: target_user_id, target_club_id, warning_status	No hard delete
penalties	Match loss, point deduction, or other formal penalty	id UUID	target_user_id -> users.id or target_club_id -> clubs.id, issued_by_user_id -> users.id, optional match_id, dispute_id	Required: penalty_type, reason, penalty_status, issued_at; Optional: points_delta, effective_from, effective_to, evidence_payload, appeal_status	penalty_status	Index: target_user_id, target_club_id, penalty_type, penalty_status	No hard delete
sanctions	Heavy restrictions such as suspension or ban	id UUID	target_user_id -> users.id or target_club_id -> clubs.id, issued_by_user_id -> users.id	Required: sanction_type, reason, sanction_status, start_at; Optional: end_at, lifted_at, scope, review_notes	sanction_status	Index: target_user_id, target_club_id, sanction_type, sanction_status	No hard delete
notifications	In-app alerts and operational messages	id UUID	user_id -> users.id, optional entity_id + entity_type	Required: notification_type, title, body, notification_status, created_at; Optional: action_url, read_at, sent_at, priority, metadata_json	notification_status	Index: (user_id, notification_status), notification_type	No
audit_logs	Append-only compliance and traceability log	id UUID	actor_user_id -> users.id	Required: entity_type, entity_id, action, metadata_json, created_at; Optional: before_data, after_data, request_id, ip_address, user_agent, correlation_id	—	Index: (entity_type, entity_id), actor_user_id, created_at	Never delete
standings	Materialized season/division leaderboard for players	id UUID	season_id -> seasons.id, division_id -> divisions.id, player_profile_id -> player_profiles.id, optional club_id_snapshot -> clubs.id	Required: matches_played, wins, draws, losses, goals_for, goals_against, goal_difference, points, rank_position, standing_status, calculated_at; Optional: tie_break_score, locked_at	standing_status	Unique: (season_id, division_id, player_profile_id); Index: (season_id, division_id, rank_position), points	No hard delete
rankings	Global or season-scoped player leaderboard snapshot	id UUID	player_profile_id -> player_profiles.id, optional season_id -> seasons.id	Required: ranking_scope_type, ranking_points, rank_position, calculated_at; Optional: scope_id, tier, win_rate, reputation_score, ranking_status	ranking_scope_type, ranking_status	Unique: (ranking_scope_type, scope_id, player_profile_id); Index: (rank_position), ranking_points	No hard delete
rewards	Symbolic season awards and trophies	id UUID	season_id -> seasons.id, optional recipient_player_profile_id -> player_profiles.id, optional recipient_club_id -> clubs.id, awarded_by_user_id -> users.id	Required: reward_type, title, awarded_at, reward_status; Optional: description, evidence_note, metadata_json	reward_status	Index: season_id, recipient_player_profile_id, recipient_club_id, reward_type	No hard delete
achievements	Persistent career badges/trophies	id UUID	player_profile_id -> player_profiles.id, optional season_id -> seasons.id, optional source_reward_id -> rewards.id	Required: achievement_type, title, earned_at; Optional: description, badge_key, visible_in_profile, metadata_json	—	Index: player_profile_id, achievement_type, season_id	No hard delete

---

4) Relationship mapping

Identity & access

users 1:1 player_profiles

users 1:1 operator_profiles

users 1:M user_roles

roles 1:M user_roles

roles M:M permissions through role_permissions

Club layer

clubs 1:M club_members

player_profiles 1:M club_members over time

clubs 1:M club_applications

player_profiles 1:M club_applications

Competition layer

seasons 1:M divisions

seasons 1:M fixtures

divisions 1:M fixtures

seasons 1:M division_members

divisions 1:M division_members

player_profiles 1:M division_members

fixtures 1:1 matches

matches 1:M match_participants

matches 1:1 results

matches 1:M disputes

Governance layer

users 1:M warnings

users 1:M penalties

users 1:M sanctions

users 1:M notifications

users 1:M audit_logs

Progression layer

seasons 1:M standings

divisions 1:M standings

player_profiles 1:M standings

player_profiles 1:M rankings

seasons 1:M rewards

player_profiles 1:M rewards

clubs 1:M rewards if a symbolic club award is issued

player_profiles 1:M achievements

---

5) Cascade and ownership rules

Do this cleanly or the schema will become a mess.

Hard rules

Never hard-delete: audit_logs, results, disputes, standings, rankings, rewards, achievements, penalties, warnings, sanctions

Use soft delete only on: users, player_profiles, clubs

seasons, divisions, fixtures, matches should be status-driven, not deleted

FK delete behavior

For historical data, use ON DELETE RESTRICT

For pure join tables like user_roles and role_permissions, ON DELETE CASCADE is acceptable, but only if your application never physically deletes parent rows

results should be blocked from deletion once verified

matches should not be deleted if a result exists

fixtures should not be deleted once published unless an admin override explicitly archives them

---

6) System rules

Unique fields

users.email

users.username

player_profiles.user_id

player_profiles.gamer_tag

clubs.club_name

clubs.slug

seasons.season_number

fixtures.fixture_code

matches.fixture_id

results.match_id

user_roles(user_id, role_id)

role_permissions(role_id, permission_id)

club_members(player_profile_id) for active membership

division_members(season_id, player_profile_id)

standings(season_id, division_id, player_profile_id)

Validation rules

A player must have an account and profile before entering a season

A player can belong to only one active club at a time

club_applications must not create duplicate pending applications for the same player and club

division_members must point to exactly one active season division per player

A fixture must have exactly two participants in MVP

player_a_profile_id != player_b_profile_id

A match must map to one fixture only

A result may be submitted once per match unless an admin override is logged

Result evidence is mandatory

A dispute must reference a match

Standings may only be updated from verified results or official forfeits

A sanctioned user cannot join a club or division until the sanction is lifted, unless HQ overrides it

Immutability rules

Once a result is verified, lock score and evidence fields

Once a dispute is resolved/closed, do not edit the ruling; append a correction only through a new audit action

Once a season is archived, standings and rankings become read-only

Once a warning/penalty/sanction is issued, do not edit the original record; use reversal/lift fields instead

audit_logs is append-only

Audit requirements

Log all of these:

account and role changes

club approval/rejection

membership create/leave/remove actions

season and division creation

fixture generation and rescheduling

match check-in decisions

result submissions and verification

dispute opening, escalation, and closure

warnings, penalties, sanctions

standings/ranking recalculations

manual overrides by operators, commissioners, or HQ

---

7) ERD in text form

erDiagram
    USERS ||--|| PLAYER_PROFILES : has
    USERS ||--|| OPERATOR_PROFILES : has
    USERS ||--o{ USER_ROLES : assigned
    ROLES ||--o{ USER_ROLES : maps
    ROLES ||--o{ ROLE_PERMISSIONS : grants
    PERMISSIONS ||--o{ ROLE_PERMISSIONS : included_in

    CLUBS ||--o{ CLUB_MEMBERS : has
    PLAYER_PROFILES ||--o{ CLUB_MEMBERS : joins
    CLUBS ||--o{ CLUB_APPLICATIONS : receives
    PLAYER_PROFILES ||--o{ CLUB_APPLICATIONS : applies

    SEASONS ||--o{ DIVISIONS : contains
    SEASONS ||--o{ DIVISION_MEMBERS : places
    DIVISIONS ||--o{ DIVISION_MEMBERS : assigns
    PLAYER_PROFILES ||--o{ DIVISION_MEMBERS : enters

    SEASONS ||--o{ FIXTURES : schedules
    DIVISIONS ||--o{ FIXTURES : groups
    FIXTURES ||--|| MATCHES : becomes
    MATCHES ||--o{ MATCH_PARTICIPANTS : includes
    MATCHES ||--|| RESULTS : has
    MATCHES ||--o{ DISPUTES : contested_by

    USERS ||--o{ WARNINGS : issued_to
    USERS ||--o{ PENALTIES : issued_to
    USERS ||--o{ SANCTIONS : restricted_by
    USERS ||--o{ NOTIFICATIONS : receives
    USERS ||--o{ AUDIT_LOGS : acts

    SEASONS ||--o{ STANDINGS : ranks
    DIVISIONS ||--o{ STANDINGS : ranks_in
    PLAYER_PROFILES ||--o{ STANDINGS : appears_in

    PLAYER_PROFILES ||--o{ RANKINGS : ranked
    SEASONS ||--o{ REWARDS : awards
    PLAYER_PROFILES ||--o{ REWARDS : receives
    CLUBS ||--o{ REWARDS : may_receive
    PLAYER_PROFILES ||--o{ ACHIEVEMENTS : earns

---

8) Implementation notes for PostgreSQL + Prisma

PostgreSQL design

Use UUID primary keys everywhere

Use timestamptz for all timestamps

Use jsonb for evidence_payload, metadata_json, before_data, after_data, and override notes

Use enums for status fields unless you prefer lookup tables

Use partial unique indexes for:

one active club membership per player

one pending club application per player/club

one result per match

one active dispute per match

one division entry per player per season

Prisma design

Use @id @default(uuid())

Use @updatedAt for updated_at

Keep operational write actions inside transactions:

result submit

result verify

dispute resolve

standings update

ranking recalculation

sanction issuance

Important modeling choice

standings and rankings should be stored snapshots, not computed on every request. That is the right call for MVP because the app needs fast homepage and dashboard reads.

Query performance

Add composite indexes for the real traffic patterns:

(season_id, division_id, rank_position) on standings

(user_id, notification_status) on notifications

(match_id, participant_status) on match participants

(player_profile_id, membership_status) on club members

(season_id, player_profile_id) on division members

What not to build yet

Transfers table

Loans table

Club-vs-club competition engine

Wallet/payout ledger

Social feed

Complex reputation scoring engine beyond cached counters
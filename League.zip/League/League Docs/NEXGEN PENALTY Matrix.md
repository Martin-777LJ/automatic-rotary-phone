NEXGEN PENALTY MATRIX
Version 1.0 (MVP)
The Penalty Matrix exists to ensure that penalties are:
Consistent
Predictable
Fair
Transparent
Operators should not invent punishments.
Every violation should map to a predefined penalty range.

1. Penalty Levels
Level 1 — Warning
Used for:
First-time minor violations
Administrative mistakes
Minor delays
Examples:
Late check-in
Incomplete profile
Minor communication issue
Effect:
Official Warning Recorded

Level 2 — Match Forfeit
Used when:
A player causes a fixture failure
A match cannot be completed due to negligence
Effect:
Loss Assigned
0 Points Awarded

Level 3 — Point Deduction
Used when:
Behavior affects league integrity
Repeated violations occur
Effect:
-1
-3
-6
Points

Depending on severity.

Level 4 — Suspension
Used when:
Serious misconduct occurs
Competitive integrity is threatened
Effect:
Temporary Removal

Duration:
1 Match
1 Week
1 Month
Entire Season

Level 5 — Permanent Ban
Used when:
League integrity is severely damaged
Effect:
Permanent Removal

HQ approval required.

2. Check-In Violations
Violation
First Offense
Repeated Offense
Late Check-In
Warning
Forfeit
Failure To Check-In
Forfeit
Suspension Review
Habitual Missed Check-In
Warning + Review
Suspension

3. No-Show Violations
Violation
Penalty
First No-Show
Match Forfeit
Second No-Show
Match Forfeit + Warning
Third No-Show
Suspension Review
Persistent No-Show Behavior
Suspension

4. Submission Violations
Violation
Penalty
Late Submission
Warning
Repeated Late Submission
Forfeit
Missing Evidence
Warning / Review
Repeated Missing Evidence
Forfeit

5. False Reporting Violations
Violation
Penalty
Incorrect Score Submitted (Mistake)
Warning
Repeated Incorrect Reporting
Forfeit
Deliberate False Reporting
Suspension
Fabricated Result
Suspension / Ban Review

6. Evidence Fraud
Violation
Penalty
Edited Screenshot
Suspension Review
Fake Evidence
Suspension
Organized Evidence Fraud
Permanent Ban Review

This category is considered high severity.

7. Conduct Violations
Violation
Penalty
Minor Abuse
Warning
Repeated Abuse
Suspension
Harassment
Suspension
Threats
Suspension
Hate Speech
Ban Review

8. Club Violations
Violation
Penalty
Unresponsive Manager
Warning
Repeated Administrative Failure
Point Deduction
False Club Reporting
Suspension Review
Club-Wide Rule Manipulation
Suspension
Organized Fraud
Club Removal Review

9. Recruitment Violations
Violation
Penalty
Unauthorized Recruitment Activity
Warning
Recruitment Tampering
Suspension Review
Recruitment Fraud
Suspension

10. Transfer Violations
Violation
Penalty
Unreported Transfer
Warning
Repeated Transfer Violation
Point Deduction
Transfer Manipulation
Suspension Review

11. Competitive Integrity Violations
This is the most important section.
Violation
Penalty
Account Sharing
Suspension
Match Manipulation
Ban Review
Collusion
Ban Review
Deliberate Standings Manipulation
Ban Review
Organized Competitive Fraud
Permanent Ban

12. Operator Violations
Violation
Penalty
Negligence
Warning
Repeated Negligence
Removal Review
Bias
Suspension Review
Abuse of Authority
Removal
Evidence Tampering
Permanent Removal

13. Club Manager Violations
Violation
Penalty
Failure To Coordinate Team
Warning
Repeated Administrative Failure
Review
Pressuring Operators
Suspension Review
Organized Manipulation
Removal + Suspension

14. Escalation Requirements
The following must be escalated:
Match Operator → Commissioner
Multiple violations
Repeat offenders
Club-level issues
Commissioner → NexGen HQ
Permanent bans
Cheating allegations
Match manipulation
Evidence fraud
Constitutional violations

15. Mitigating Factors
Penalties may be reduced when:
First offense
Genuine mistake
Immediate correction
Full cooperation

16. Aggravating Factors
Penalties may increase when:
Repeated behavior
Intentional misconduct
Multiple violations
Refusal to cooperate
Impact on league integrity

17. Penalty Record Template
Every penalty should contain:
Penalty ID

Participant

Club

Division

Violation

Evidence

Penalty Applied

Operator

Date

Appeal Status
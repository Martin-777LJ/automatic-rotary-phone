NEXGEN DISPUTE RESOLUTION SOP(Standard Operation Procedures) 

Version 1.0 (MVP)

1. Purpose

The purpose of this SOP is to ensure that all disputes are handled:

Fairly

Consistently

Transparently

Using evidence

Within defined timelines

This SOP applies to:

Players

Clubs

Managers

Operators

Commissioners

---

2. Dispute Principles

Every dispute must follow:

Evidence First

Decisions are based on evidence.

Not:

Reputation

Popularity

Personal relationships

---

Neutrality

Operators must remain neutral.

No favoritism.

No club bias.

No personal involvement.

---

Timeliness

Disputes should be resolved quickly.

Delayed decisions affect:

Fixtures

Standings

Playoffs

---

Documentation

Every dispute must be recorded.

No verbal-only rulings.

---

3. Dispute Categories

Category A — Match Result Disputes

Examples:

Wrong score submitted

Score entered incorrectly

Opponent submitted false result

---

Category B — No-Show Disputes

Examples:

Opponent never appeared

Opponent never checked in

Opponent abandoned fixture

---

Category C — Disconnect Disputes

Examples:

Connection loss

System crash

Match interrupted

---

Category D — Rule Violation Disputes

Examples:

Incorrect match settings

Unauthorized participant

Eligibility breach

---

Category E — Conduct Disputes

Examples:

Harassment

Abuse

Threats

Toxic behavior

---

Category F — Integrity Disputes

Examples:

Cheating

Match manipulation

Fake evidence

Account sharing

These are high-priority cases.

---

4. Dispute Submission Requirements

Every dispute must include:

Required

Match ID

Player names

Description of issue

Evidence

---

Evidence Types

Acceptable:

Screenshots

Match summaries

Video clips

Platform logs

---

Not acceptable:

Hearsay

Rumors

Third-party assumptions

---

5. Dispute Timeline

Stage 1 — Submission

Player submits dispute.

Deadline:

Within dispute window.

Recommended MVP:

12 Hours after result submission

---

Stage 2 — Initial Review

Operator reviews:

Evidence

Rulebook

Match record

Target:

24 Hours

---

Stage 3 — Ruling

Operator decides:

Outcome A

Approve dispute

Outcome B

Reject dispute

Outcome C

Escalate dispute

---

6. Investigation Procedure

Operator must:

Step 1

Review fixture.

---

Step 2

Review evidence.

---

Step 3

Review opponent evidence.

---

Step 4

Review relevant rules.

---

Step 5

Make ruling.

---

Step 6

Record decision.

---

7. No-Show Investigation

Operator checks:

Check-In Logs

Did player check in?

---

Activity Logs

Was player active?

---

Communication Records

Did player respond?

---

Possible outcomes:

No-show confirmed

Match rescheduled

Warning issued

Forfeit issued

---

8. Disconnect Investigation

Operator determines:

When disconnect happened

Early

Mid-game

Late-game

---

Impact

Did disconnect affect result?

---

Possible outcomes:

Replay

Continue result

Partial replay

Escalation

---

9. False Reporting Investigation

High severity.

Operator checks:

Screenshot validity

Match history

Opponent evidence

If fraud confirmed:

Immediate escalation.

---

10. Cheating Investigation

Examples:

Exploits

Unauthorized tools

Account sharing

Deliberate manipulation

Operator gathers evidence.

Commissioner reviews.

HQ decides final action.

---

11. Penalty Recommendations

Minor

Warning

---

Moderate

Match Forfeit

Point Deduction

---

Major

Suspension

---

Severe

Permanent Ban

---

12. Escalation Matrix

Match Operator

Can resolve:

Standard disputes

Result issues

No-shows

---

Commissioner

Handles:

Complex cases

Repeated offenders

Division-impacting rulings

---

NexGen HQ

Handles:

Cheating

Permanent bans

Appeals

Constitutional matters

---

13. Appeals Process

A participant may appeal:

If:

New evidence exists

Major procedural error occurred

---

Cannot appeal simply because:

"I don't like the decision."

---

14. Final Authority

NexGen HQ retains final authority.

Once HQ issues a final ruling:

Case status:

Closed

No further escalation.

---

15. Dispute Record Template

Every dispute should store:

Dispute ID

Match ID

Division

Players Involved

Category

Evidence Submitted

Operator Assigned

Decision

Penalty

Appeal Status

Date Closed
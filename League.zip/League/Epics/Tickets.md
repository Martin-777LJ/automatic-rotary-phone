NexGen MVP Development Tickets

Progress Tracking Model

Track execution at the story/ticket level, not the feature level.

Workflow: Backlog → Ready → In Progress → Code Review → Testing → Done

Per ticket fields:

Ticket ID

Epic

Story IDs covered

Priority (P0 / P1 / P2)

Sprint

Owner

Dependencies

Status

Definition of Done

Notes / blockers


Project health counters:

Planned

Started

Completed

Blocked



---

Milestone Plan

Milestone 1 — Foundation

Covers identity, access control, and player profile basics.

Milestone 2 — Club Layer

Covers clubs, membership, and approvals.

Milestone 3 — Competition Core

Covers seasons, divisions, fixtures, matches, check-in, and results.

Milestone 4 — Governance Core

Covers disputes, penalties, sanctions, standings, and audit visibility.

Milestone 5 — Operational Layer

Covers notifications, realtime, moderation, support, and security hardening.

Milestone 6 — Production Readiness

Covers deployment, monitoring, backups, release flow, and recovery.


---

Development Tickets

TICKET-001 — Auth Foundation

Epic: Identity, Authentication, and Session Control
Stories: AUTH-001, AUTH-002, AUTH-003, AUTH-004, AUTH-005
Priority: P0
Sprint: 1
Dependencies: None

Scope:

Registration endpoint

Email verification flow

Login/logout flow

Refresh token session storage

Password reset flow

Failed login throttling


Definition of Done:

User can register, verify email, log in, log out, and reset password

Session tokens are revocable

Security and audit events are recorded

Tests cover success and failure paths



---

TICKET-002 — RBAC and Authorization Core

Epic: Role, Permission, and Access Control
Stories: RBAC-001, RBAC-002, RBAC-003
Priority: P0
Sprint: 1
Dependencies: TICKET-001

Scope:

Roles and permissions model

Permission middleware

Ownership checks

Resource-state checks

Operator scope restriction


Definition of Done:

Every protected endpoint enforces role + ownership + state checks

Unauthorized access is rejected consistently

Scope violations are blocked and logged

Tests cover role and ownership edge cases



---

TICKET-003 — Player Profile Core

Epic: Core User and Player Profile System
Stories: PLAYER-001, PLAYER-002, PLAYER-003
Priority: P0
Sprint: 2
Dependencies: TICKET-001, TICKET-002

Scope:

Player profile creation

Public player profile view

Editable profile fields

Competitive status fields

Career stats storage


Definition of Done:

Player profiles are linked to user accounts

Public/private fields are enforced correctly

Profile updates are audited

Tests validate visibility and update rules



---

TICKET-004 — Club Core

Epic: Club System
Stories: CLUB-001, CLUB-002, CLUB-003
Priority: P0
Sprint: 2
Dependencies: TICKET-002, TICKET-003

Scope:

Club creation

Club ownership

Club profile updates

Manager and staff assignment

Club suspension controls


Definition of Done:

Clubs can be created and managed under correct permissions

Club ownership and role assignment are enforced

Audit events are recorded for club mutations

Tests cover duplicate names and unauthorized edits



---

TICKET-005 — Membership and Recruitment Workflow

Epic: Club Applications and Membership Workflow
Stories: MEMBERSHIP-001, MEMBERSHIP-002, MEMBERSHIP-003
Priority: P0
Sprint: 2
Dependencies: TICKET-004

Scope:

Apply to club

Review application

Accept/reject application

Remove/suspend member

Recruitment pool visibility


Definition of Done:

Players can apply to clubs

Clubs can approve/reject applications

Membership state transitions are correct

History is preserved and audited



---

TICKET-006 — Season and Division Management

Epic: Season and Division Management
Stories: SEASON-001, SEASON-002, SEASON-003, DIVISION-001
Priority: P0
Sprint: 3
Dependencies: TICKET-002, TICKET-004

Scope:

Season creation

Season publish/open/close/archive

Division creation

Division-to-season assignment

Operator scope assignment


Definition of Done:

HQ can manage season lifecycle

Divisions are scoped correctly

Invalid transitions are blocked

State changes are audited



---

TICKET-007 — Fixture Generation and Match Lifecycle

Epic: Fixture and Match Operations
Stories: MATCH-001, MATCH-004
Priority: P0
Sprint: 3
Dependencies: TICKET-006

Scope:

Fixture creation

Match scheduling

Match state machine storage

Fixture publication

Match detail view


Definition of Done:

Fixtures can be generated without collisions

Match state transitions are enforced

Match records are queryable by users and operators

All state mutations are audited



---

TICKET-008 — Check-In and No-Show Automation

Epic: Fixture and Match Operations
Stories: MATCH-002, MATCH-003
Priority: P0
Sprint: 3
Dependencies: TICKET-007

Scope:

Open check-in job

Close check-in job

Manual override actions

No-show scan job

Forfeit review queue


Definition of Done:

Check-in opens and closes on schedule

No-show cases are flagged correctly

Operators can override with audit logging

Jobs are idempotent



---

TICKET-009 — Result Submission and Verification

Epic: Result Submission and Verification
Stories: RESULT-001, RESULT-002, RESULT-003
Priority: P0
Sprint: 4
Dependencies: TICKET-007, TICKET-008

Scope:

Result submission

Evidence upload links

Opponent confirmation/rejection

Operator verification queue

HQ override


Definition of Done:

Players can submit results with evidence

Opponents can confirm or reject

Operators can review and finalize

Standings are updated on confirmation

Before/after state snapshots are available



---

TICKET-010 — Dispute System

Epic: Disputes, Penalties, and Sanctions
Stories: DISPUTE-001, DISPUTE-002, DISPUTE-003, DISPUTE-004
Priority: P0
Sprint: 4
Dependencies: TICKET-009

Scope:

Open dispute

Add evidence

Operator review queue

Resolve dispute

Appeal flow


Definition of Done:

Disputes can be created and tracked end to end

Evidence is attached and preserved

Review and appeal states are correct

Actions are logged and visible to authorized users



---

TICKET-011 — Discipline Enforcement

Epic: Disputes, Penalties, and Sanctions
Stories: PENALTY-001, PENALTY-002, SANCTION-001
Priority: P1
Sprint: 4
Dependencies: TICKET-010

Scope:

Warning issuance

Penalty issuance

HQ sanction issuance

Rule references

Discipline history


Definition of Done:

Discipline actions are role-restricted

All disciplinary actions are auditable

Competition impact is reflected correctly

Tests cover invalid scope and permission cases



---

TICKET-012 — Standings and Rankings Engine

Epic: Standings, Rankings, and Rewards
Stories: STANDINGS-001, STANDINGS-002, STANDINGS-003, REWARD-001
Priority: P0
Sprint: 4
Dependencies: TICKET-009, TICKET-011

Scope:

Standings recalculation service

Public leaderboard endpoint

Manual correction path

Reward assignment hooks


Definition of Done:

Standings recalculate deterministically from official outcomes

Public views only expose safe data

Manual changes require HQ permission and reason

Rewards can be attached to season outcomes



---

TICKET-013 — Notifications Engine

Epic: Notifications and Realtime
Stories: NOTIFY-001, NOTIFY-002, NOTIFY-003
Priority: P1
Sprint: 5
Dependencies: TICKET-007, TICKET-009, TICKET-010

Scope:

Notification table and service

Match reminder notifications

Dispute status notifications

Read/unread state

Delivery logging


Definition of Done:

Users receive relevant in-app notifications

Important workflow events trigger notifications

Duplicate notifications are prevented

Notification state is persisted



---

TICKET-014 — Realtime Delivery

Epic: Notifications and Realtime
Stories: REALTIME-001
Priority: P1
Sprint: 5
Dependencies: TICKET-012, TICKET-013

Scope:

Realtime event contracts

Pusher integration

Live standings updates

Live match status updates

Live dispute updates

Polling fallback


Definition of Done:

Realtime pushes occur for supported events

Database remains source of truth

Client fallback works if push delivery fails

Tests verify event publication paths



---

TICKET-015 — Audit Logging Core

Epic: Audit Logging and Admin Oversight
Stories: AUDIT-001, AUDIT-003
Priority: P0
Sprint: 5
Dependencies: TICKET-002, TICKET-009, TICKET-010, TICKET-011

Scope:

Append-only audit log schema

Audit middleware/service

Before/after snapshots

Override tracking

Immutable write behavior


Definition of Done:

Sensitive actions always create audit records

Audit rows cannot be edited or deleted

Override actions include reason and snapshots

Tests enforce append-only behavior



---

TICKET-016 — Audit Search and HQ Oversight

Epic: Audit Logging and Admin Oversight
Stories: AUDIT-002
Priority: P1
Sprint: 5
Dependencies: TICKET-015

Scope:

Audit search endpoint

Filters by actor/action/resource/date

Pagination

HQ-only access control


Definition of Done:

HQ can search and filter audit history

Data access is restricted correctly

Results are paginated and secure



---

TICKET-017 — Moderation Tools

Epic: Moderation and Support Tools
Stories: MOD-001, MOD-002, MOD-003
Priority: P1
Sprint: 5
Dependencies: TICKET-002, TICKET-015

Scope:

Content flagging

Hide/unhide moderation

Abuse report creation

Moderate queue

Limited evidence access


Definition of Done:

Moderators can triage reports without touching competition truth

Actions are scoped and audited

Support surfaces stay read-only where required



---

TICKET-018 — Support and Account Recovery

Epic: Moderation and Support Tools
Stories: SUPPORT-001, SUPPORT-002
Priority: P1
Sprint: 5
Dependencies: TICKET-001, TICKET-002, TICKET-015

Scope:

Support case management

Account lookup for recovery

Safe recovery flow

Escalation tracking


Definition of Done:

Support can help users without unauthorized edits

Recovery actions are logged

Sensitive account operations are protected



---

TICKET-019 — Security Controls and Abuse Prevention

Epic: Security, Abuse Prevention, and Rate Limiting
Stories: SECURITY-001, SECURITY-002, SECURITY-003, SECURITY-004
Priority: P0
Sprint: 1-5 (cross-cutting)
Dependencies: TICKET-001, TICKET-009, TICKET-015

Scope:

Password policy enforcement

OTP throttling

Login throttling

Duplicate-account heuristics

Fraud detection rules

Upload validation


Definition of Done:

Security rules are enforced server-side

Abuse paths are rate limited or blocked

Uploads are validated and stored safely

Security events are auditable



---

TICKET-020 — Infrastructure and Environment Setup

Epic: Infrastructure, Deployment, and Operations
Stories: OPS-001, OPS-002, OPS-003, OPS-004, OPS-005, OPS-006, OPS-007
Priority: P0
Sprint: 1-6
Dependencies: None

Scope:

Development/staging/production environment setup

PostgreSQL provisioning

Object storage configuration

Job scheduling

Monitoring and alerts

Backups and recovery

Release and rollback process


Definition of Done:

All environments are defined

Database and storage are provisioned safely

Scheduled jobs run reliably

Monitoring and backup processes exist

Release flow is documented and testable





Suggested Execution Order

1. TICKET-020


2. TICKET-001


3. TICKET-002


4. TICKET-003


5. TICKET-004


6. TICKET-005


7. TICKET-006


8. TICKET-007


9. TICKET-008


10. TICKET-009


11. TICKET-010


12. TICKET-011


13. TICKET-012


14. TICKET-013


15. TICKET-014


16. TICKET-015


17. TICKET-016


18. TICKET-017


19. TICKET-018


20. TICKET-019



Ticketing Rule

Do not let any ticket grow beyond one sprint worth of work. If a ticket is too large, split it before implementation starts.
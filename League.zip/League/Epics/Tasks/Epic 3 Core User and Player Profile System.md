PLAYER-001 Create player profile
Create player profile table
Link profile to user account
Add gamer tag validation
Add profile creation endpoint
Set default player status
Audit profile creation
Add tests for duplicate tag and invalid profile data
PLAYER-002 Public player profile
Build public player profile read endpoint
Hide private fields from guests
Expose stats and competition history
Add pagination for history
Add caching if needed
Add visibility tests
PLAYER-003 Profile edits
Define editable fields
Build profile update endpoint
Validate state and permissions
Preserve audit trail for edits
Add tests for restricted fields and invalid updates
Epic 7 — Fixture and Match Operations
MATCH-001 Fixture generation
Build fixture schema
Create fixture generation service
Add admin/operator fixture endpoint
Prevent duplicate fixtures
Audit fixture publication
Add tests for schedule collisions
MATCH-002 Check-in open/close
Create check-in state fields
Build scheduled job to open check-in
Build scheduled job to close check-in
Add manual override endpoint
Notify participants
Audit every transition
Add tests for idempotent job runs
MATCH-003 No-show detection
Build no-show scan job
Add provisional no-show flag
Create operator review queue item
Block auto-final forfeit unless policy allows
Audit scan and decision
Add tests for late check-ins and edge timing
MATCH-004 Match lifecycle tracking
Implement match state machine storage
Add match detail endpoint
Track all state transitions
Block invalid transitions
Audit every mutation
Add tests for state integrity
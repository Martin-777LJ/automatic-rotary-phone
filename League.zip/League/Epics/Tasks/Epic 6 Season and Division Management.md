Epic 6 — Season and Division Management
SEASON-001 Create season
Create season schema
Add season creation endpoint
Validate dates and status
Seed initial season metadata
Audit creation
Add tests for invalid date ranges
SEASON-002 Publish/open season
Build season status transition service
Add registration-open endpoint or admin action
Trigger notifications
Prevent invalid transitions
Audit state change
Add tests for blocked transitions
SEASON-003 Close/archive season
Build close/archive transition flow
Freeze season data
Restrict post-close edits
Audit archive action
Add tests for immutable closed season records
DIVISION-001 Create and assign divisions
Create division schema
Build division creation endpoint
Link divisions to seasons
Add operator scope assignment logic
Audit division actions
Add tests for unauthorized creation
CLUB-001 Club creation
Create club schema
Link club to owner
Validate unique club name
Build club creation endpoint
Initialize club status
Audit club creation
Add tests for duplicates and unauthorized creation

CLUB-002 Club profile management
Build club update endpoint
Restrict edits to owner/manager scope
Add logo/banner upload hooks
Add status validation
Audit profile changes
Add tests for unauthorized edits

CLUB-003 Staff assignment and ownership handling
Create club role assignment logic
Build manager/staff assignment endpoints
Add ownership override rules
Audit role changes
Add tests for invalid assignment and permissions
RBAC-001 Role assignment
Create roles/permissions tables or enums
Seed default role matrix
Build admin role assignment service
Add role-change audit logging
Validate only authorized HQ actions can assign roles
Add tests for each role edge case
RBAC-002 Authorization enforcement
Build permission middleware
Build ownership-check helper
Build resource-state guard helper
Standardize denied-response format
Apply guards to protected routes
Add tests for unauthorized, wrong-owner, wrong-state access
RBAC-003 Operator scope restriction
Add division/season scope mapping
Restrict operator queries by scope
Restrict operator actions by scope
Log scope violations
Add tests for cross-division access denial
MEMBERSHIP-001 Apply to club
Create club application table
Add application endpoint
Prevent duplicate pending applications
Add recruitment pool query
Notify club staff on new application
Audit application submission
Add tests for duplicate and blocked applications
MEMBERSHIP-002 Review applications
Build approve/reject endpoints
Validate club manager/owner permissions
Create membership record on approval
Update application status
Notify player
Audit review decision
Add tests for invalid review states
MEMBERSHIP-003 Remove/suspend member
Build remove/suspend endpoints
Block self-removal edge cases if needed
Preserve membership history
Notify affected player
Audit member removal
Add tests for ownership and role restrictions
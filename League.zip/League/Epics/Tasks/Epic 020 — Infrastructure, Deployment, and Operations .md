Epic 020 — Infrastructure, Deployment, and Operations
OPS-001 Environment setup
Define local/dev/staging/prod config
Load secrets from managed secret store
Add environment validation on boot
Document required env vars
Add tests for missing config
OPS-002 Database and storage
Provision PostgreSQL schema
Add migrations pipeline
Configure object storage buckets
Add backup schedule
Add restore verification task
OPS-003 Jobs and scheduling
Set up job runner/cron system
Schedule check-in and deadline jobs
Schedule standings recomputation jobs
Make jobs idempotent
Add job failure logging
OPS-004 Monitoring and release flow
Add structured logging
Add health checks
Add alerting for API/db/job failures
Define staging smoke test
Define production release steps
Add rollback procedure
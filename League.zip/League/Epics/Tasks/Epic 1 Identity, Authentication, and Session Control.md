AUTH-001 / AUTH-002 Registration and email verification
Create users auth schema fields
Add unique email validation
Enforce password policy
Build registration endpoint
Generate verification token
Send verification email
Build verification endpoint
Mark account verified
Log registration and verification audit events
Add tests for expiry, reuse, duplicate email, invalid token

AUTH-003 / AUTH-004 Login and rate limiting
Build login endpoint
Validate credentials
Issue access token
Issue refresh token
Store hashed refresh-session record
Add login throttling middleware
Add failed-login audit logging
Add session revocation logic
Add tests for lockout and token expiry
AUTH-005 Password recovery
Build forgot-password request endpoint
Generate reset token
Send reset email
Build password reset endpoint
Invalidate old sessions after reset
Audit password reset actions
Test expired token, reused token, and invalid email cases